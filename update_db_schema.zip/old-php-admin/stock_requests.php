<?php
include '../config/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';

$branch_id = $_SESSION['branch_id'] ?? null;
if ($_SESSION['role'] === 'admin' && empty($branch_id) && isset($_GET['branch_view'])) {
    $branch_id = $_GET['branch_view'];
}

// Fetch Products
$products = $pdo->query("SELECT id, name FROM products ORDER BY name")->fetchAll();

// Branches for dropdown (Exclude current if selected)
$branch_sql = "SELECT id, name FROM branches";
if (!empty($branch_id)) {
    $branch_sql .= " WHERE id != $branch_id";
}
$branches = $pdo->query($branch_sql)->fetchAll();

// Logic:
// If Branch ID is set: Show requests involving that branch.
// If Super Admin (Global): Show ALL requests.

if (!empty($branch_id)) {
    // Branch View
    $incoming = $pdo->query("
        SELECT sr.*, p.name as product_name, b.name as requester_name 
        FROM stock_requests sr
        JOIN products p ON sr.product_id = p.id
        JOIN branches b ON sr.requester_branch_id = b.id
        WHERE sr.provider_branch_id = $branch_id
        ORDER BY sr.requested_at DESC
    ")->fetchAll();

    $outgoing = $pdo->query("
        SELECT sr.*, p.name as product_name, b.name as provider_name 
        FROM stock_requests sr
        JOIN products p ON sr.product_id = p.id
        JOIN branches b ON sr.provider_branch_id = b.id
        WHERE sr.requester_branch_id = $branch_id
        ORDER BY sr.requested_at DESC
    ")->fetchAll();
} else {
    // Super Admin Global View (Show Everything)
    // We might need a different UI for this, but for now let's listing all
    // Treat 'Incoming' as 'All Requests' for simplicity or split?
    // Let's just show all in Incoming tab for now, or separate.
    $incoming = $pdo->query("
        SELECT sr.*, p.name as product_name, b.name as requester_name, bp.name as provider_name
        FROM stock_requests sr
        JOIN products p ON sr.product_id = p.id
        JOIN branches b ON sr.requester_branch_id = b.id
        JOIN branches bp ON sr.provider_branch_id = bp.id
        ORDER BY sr.requested_at DESC
    ")->fetchAll();
    
    $outgoing = []; // Clear outgoing tab for global view
}
?>

<div class="main-content">
    <?php include 'includes/topbar.php'; ?>

    <div class="container-fluid p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-0">Stock Requests</h2>
            <button class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#newRequestModal">
                <i class="fas fa-paper-plane me-2"></i> New Request
            </button>
        </div>

        <ul class="nav nav-tabs mb-4" id="requestTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active fw-bold" id="incoming-tab" data-bs-toggle="tab" data-bs-target="#incoming" type="button">Incoming Requests</button>
            </li>
            <li class="nav-item">
                <button class="nav-link fw-bold" id="outgoing-tab" data-bs-toggle="tab" data-bs-target="#outgoing" type="button">My Requests (Outgoing)</button>
            </li>
        </ul>

        <div class="tab-content" id="requestTabsContent">
            <!-- Incoming Requests Tab -->
            <div class="tab-pane fade show active" id="incoming">
                <div class="table-card">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">Date</th>
                                    <th>Requester</th>
                                    <th>Product</th>
                                    <th>Qty</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($incoming as $req): ?>
                                    <tr>
                                        <td class="ps-4 small text-muted"><?php echo date('M d, Y', strtotime($req['requested_at'])); ?></td>
                                        <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($req['requester_name']); ?></span></td>
                                        <td class="fw-bold"><?php echo htmlspecialchars($req['product_name']); ?></td>
                                        <td class="fw-bold"><?php echo $req['quantity']; ?></td>
                                        <td>
                                            <?php 
                                            $badge = match($req['status']) {
                                                'pending' => 'warning-subtle text-warning border border-warning-subtle',
                                                'approved' => 'success-subtle text-success border border-success-subtle',
                                                'rejected' => 'danger-subtle text-danger border border-danger-subtle',
                                                default => 'secondary'
                                            };
                                            echo "<span class='badge bg-$badge'>" . ucfirst($req['status']) . "</span>";
                                            ?>
                                        </td>
                                        <td>
                                            <?php if($req['status'] === 'pending'): ?>
                                                <form action="api/request_action.php" method="POST" class="d-inline">
                                                    <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                                                    <button type="submit" name="action" value="approve" class="btn btn-sm btn-success-subtle text-success border-success" title="Approve"><i class="fas fa-check"></i></button>
                                                    <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger-subtle text-danger border-danger" title="Reject"><i class="fas fa-times"></i></button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if(empty($incoming)): ?><tr><td colspan="6" class="text-center py-5 text-muted">No incoming requests.</td></tr><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Outgoing Requests Tab -->
            <div class="tab-pane fade" id="outgoing">
                <div class="table-card">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">Date</th>
                                    <th>Provider</th>
                                    <th>Product</th>
                                    <th>Qty</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($outgoing as $req): ?>
                                    <tr>
                                        <td class="ps-4 small text-muted"><?php echo date('M d, Y', strtotime($req['requested_at'])); ?></td>
                                        <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($req['provider_name']); ?></span></td>
                                        <td class="fw-bold"><?php echo htmlspecialchars($req['product_name']); ?></td>
                                        <td class="fw-bold"><?php echo $req['quantity']; ?></td>
                                        <td>
                                            <?php 
                                            $badge = match($req['status']) {
                                                'pending' => 'warning-subtle text-warning border border-warning-subtle',
                                                'approved' => 'success-subtle text-success border border-success-subtle',
                                                'rejected' => 'danger-subtle text-danger border border-danger-subtle',
                                                default => 'secondary'
                                            };
                                            echo "<span class='badge bg-$badge'>" . ucfirst($req['status']) . "</span>";
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if(empty($outgoing)): ?><tr><td colspan="5" class="text-center py-5 text-muted">No outgoing requests.</td></tr><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- New Request Modal -->
<div class="modal fade" id="newRequestModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Request Stock</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="api/request_action.php" method="POST">
                <input type="hidden" name="action" value="create">
                <div class="modal-body pt-4">
                    <div class="mb-3">
                        <label class="form-label text-muted small text-uppercase fw-bold">Select Product</label>
                        <select class="form-select" name="product_id" required>
                            <?php foreach($products as $p): ?>
                                <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small text-uppercase fw-bold">Request From Branch</label>
                        <select class="form-select" name="provider_branch_id" required>
                            <?php foreach($branches as $b): ?>
                                <option value="<?php echo $b['id']; ?>"><?php echo htmlspecialchars($b['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small text-uppercase fw-bold">Quantity Needed</label>
                        <input type="number" class="form-control form-control-lg" name="quantity" required min="1">
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 pb-4 pe-4">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary-custom px-4">Send Request</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
