<?php
include '../config/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';

// --- Dashboard Logic ---
$role = $_SESSION['role'];
$branch_id = $_SESSION['branch_id'] ?? null;
$user_name = $_SESSION['fullname'] ?? 'Admin';
$view_branch_name = null;

// Handle Branch View Override for Super Admin
if ($role === 'admin' && empty($_SESSION['branch_id']) && isset($_GET['branch_view'])) {
    $branch_id = $_GET['branch_view']; // Temporarily view specific branch
    // Fetch branch name for context
    $b_stmt = $pdo->prepare("SELECT name FROM branches WHERE id = ?");
    $b_stmt->execute([$branch_id]);
    $view_branch_name = $b_stmt->fetchColumn();
}

try {
    $stats = [];
    
    // SQL Conditions
    $branch_cond = (!empty($branch_id)) ? "AND branch_id = $branch_id" : "";
    
    // 1. Orders
    $stmt = $pdo->query("SELECT COUNT(*) FROM orders WHERE 1=1 $branch_cond");
    $stats['orders'] = $stmt->fetchColumn();

    // 2. Revenue
    $stmt = $pdo->query("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE status = 'completed' $branch_cond");
    $stats['revenue'] = $stmt->fetchColumn();

    // 3. Products (Global for now, or per branch if inventory table has branch_id)
    // Assuming inventory table has branch_id based on previous file reads?
    // Let's check inventory.php logic later. For now, let's assume products table is global catalog, 
    // and if we track stock per branch, we should join/filter.
    // Based on previous code: "SELECT COUNT(*) FROM inventory WHERE branch_id = ?"
    if (!empty($branch_id)) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM products"); // Products are global catalog usually
        // But stock is local?
        // Let's stick to safe global count for products, or if inventory is separate:
        // Checking previous code: $pdo->query("SELECT COUNT(*) FROM inventory...
        // Wait, previous code used 'inventory' table in the ELSE block but 'products' in IF block? 
        // Let's standardize to 'products' for count, assuming standard catalog.
        $stats['products'] = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    } else {
        $stats['products'] = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    }

    // 4. Low Stock
    // Use inventory table which has quantity
    if (!empty($branch_id)) {
         $stmt = $pdo->query("SELECT COUNT(*) FROM inventory WHERE branch_id = $branch_id AND quantity < 10");
         $stats['low_stock'] = $stmt->fetchColumn();
    } else {
         $stats['low_stock'] = $pdo->query("SELECT COUNT(*) FROM inventory WHERE quantity < 10")->fetchColumn();
    }

    // Recent Orders
    $sql_orders = "SELECT o.*, u.fullname, b.name as branch_name 
                   FROM orders o 
                   JOIN users u ON o.user_id = u.id 
                   LEFT JOIN branches b ON o.branch_id = b.id 
                   WHERE 1=1 $branch_cond
                   ORDER BY o.order_date DESC LIMIT 5";
    $stmt_orders = $pdo->query($sql_orders);
    
    
    $recent_orders = $stmt_orders->fetchAll();

    // Chart Data: Last 7 Days Sales
    $sales_data = [];
    $dates = [];
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $dates[] = date('D', strtotime($date));
        
        $sql_chart = "SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE DATE(order_date) = ? AND status != 'cancelled' $branch_cond";
        $stmt = $pdo->prepare($sql_chart);
        $stmt->execute([$date]);
        $sales_data[] = $stmt->fetchColumn();
    }

} catch(Exception $e) {
    error_log("Dashboard Error: " . $e->getMessage());
}
?>

<div class="main-content">
    <?php include 'includes/topbar.php'; ?>

    <div class="container-fluid p-4">
        <!-- Welcome Hero -->
        <!-- Welcome Hero -->
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div>
                <h2 class="fw-bold text-dark mb-1">
                    <?php if($view_branch_name): ?>
                        Dashboard: <span class="text-primary"><?php echo htmlspecialchars($view_branch_name); ?></span>
                    <?php else: ?>
                        Welcome back, <?php echo htmlspecialchars($user_name); ?>! 👋
                    <?php endif; ?>
                </h2>
                <p class="text-muted mb-0">
                    <?php echo $view_branch_name ? "Viewing statistics for this specific branch." : "Here's what's happening in your store today."; ?>
                </p>
                <?php if($view_branch_name): ?>
                    <a href="stores.php" class="btn btn-sm btn-light border mt-2"><i class="fas fa-arrow-left me-1"></i> Back to All Stores</a>
                <?php endif; ?>
            </div>
            <div class="d-none d-md-block">
                <span class="badge bg-white border text-muted px-3 py-2 rounded-pill shadow-sm">
                    <i class="far fa-calendar-alt me-2"></i> <?php echo date('F d, Y'); ?>
                </span>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="stat-icon bg-primary-subtle text-primary">
                            <i class="fas fa-shopping-bag"></i>
                        </div>
                        <span class="badge bg-success-subtle text-success">+12% <i class="fas fa-arrow-up small"></i></span>
                    </div>
                    <h6 class="text-muted text-uppercase small fw-bold mb-1">Total Orders</h6>
                    <h3 class="fw-bold text-dark mb-0"><?php echo number_format($stats['orders']); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="stat-icon bg-success-subtle text-success">
                            <i class="fas fa-rupee-sign"></i>
                        </div>
                        <span class="badge bg-success-subtle text-success">+8.5% <i class="fas fa-arrow-up small"></i></span>
                    </div>
                    <h6 class="text-muted text-uppercase small fw-bold mb-1">Total Revenue</h6>
                    <h3 class="fw-bold text-dark mb-0">₹<?php echo number_format($stats['revenue']); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="stat-icon bg-info-subtle text-info">
                            <i class="fas fa-boxes"></i>
                        </div>
                        <span class="badge bg-light text-muted">Stable</span>
                    </div>
                    <h6 class="text-muted text-uppercase small fw-bold mb-1"><?php echo $role === 'admin' ? 'Total Products' : 'In Stock'; ?></h6>
                    <h3 class="fw-bold text-dark mb-0"><?php echo number_format($stats['products']); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="stat-icon bg-warning-subtle text-warning">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <?php if($stats['low_stock'] > 0): ?>
                            <span class="badge bg-danger-subtle text-danger">Action Req.</span>
                        <?php else: ?>
                            <span class="badge bg-success-subtle text-success">All Good</span>
                        <?php endif; ?>
                    </div>
                    <h6 class="text-muted text-uppercase small fw-bold mb-1">Low Stock Alerts</h6>
                    <h3 class="fw-bold text-dark mb-0"><?php echo number_format($stats['low_stock']); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Sales Chart -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm rounded-4 h-100 p-4">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="fw-bold mb-0">Sales Overview (Last 7 Days)</h5>
                    </div>
                    <canvas id="salesChart" height="300"></canvas>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-header bg-white py-3 border-bottom px-4">
                        <h5 class="mb-0 fw-bold">Quick Actions</h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="d-grid gap-3">
                            <a href="inventory.php" class="btn btn-outline-primary text-start p-3 hover-lift border-0 bg-primary-subtle text-primary fw-bold">
                                <i class="fas fa-plus-circle me-3 fa-lg"></i> 
                                <?php echo $role === 'admin' ? 'Add New Product' : 'Update Inventory'; ?>
                            </a>
                            <a href="stock_requests.php" class="btn btn-outline-success text-start p-3 hover-lift border-0 bg-success-subtle text-success fw-bold">
                                <i class="fas fa-truck-loading me-3 fa-lg"></i> Create Stock Request
                            </a>
                            <a href="orders.php" class="btn btn-outline-dark text-start p-3 hover-lift border-0 bg-dark-subtle text-dark fw-bold">
                                <i class="fas fa-clipboard-list me-3 fa-lg"></i> Manage Orders
                            </a>
                            <?php if($role === 'admin'): ?>
                            <a href="users.php" class="btn btn-outline-info text-start p-3 hover-lift border-0 bg-info-subtle text-info fw-bold">
                                <i class="fas fa-user-plus me-3 fa-lg"></i> Register New Staff
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Orders -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="table-card">
                    <div class="table-header">
                        <div>
                            <h5 class="mb-0 fw-bold">Recent Orders</h5>
                            <small class="text-muted">Latest transactions from your store</small>
                        </div>
                        <a href="orders.php" class="btn btn-sm btn-primary-custom">View All Orders</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">Order ID</th>
                                    <th>Customer</th>
                                    <?php if($role === 'admin'): ?><th>Branch</th><?php endif; ?>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($recent_orders)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-5 text-muted">
                                            <i class="fas fa-box-open fa-3x mb-3 text-light"></i><br>
                                            No recent orders found.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach($recent_orders as $order): ?>
                                    <tr>
                                        <td class="ps-4 fw-bold text-primary">#<?php echo $order['id']; ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-sm bg-light text-primary rounded-circle me-2 d-flex align-items-center justify-content-center fw-bold small">
                                                    <?php echo strtoupper(substr($order['fullname'], 0, 1)); ?>
                                                </div>
                                                <span class="fw-medium"><?php echo htmlspecialchars($order['fullname']); ?></span>
                                            </div>
                                        </td>
                                        <?php if($role === 'admin'): ?>
                                            <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($order['branch_name'] ?? 'N/A'); ?></span></td>
                                        <?php endif; ?>
                                        <td class="text-muted small"><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                                        <td class="fw-bold">₹<?php echo number_format($order['total_amount']); ?></td>
                                        <td>
                                            <?php 
                                            $status_class = match($order['status']) {
                                                'completed' => 'bg-success-subtle text-success border border-success-subtle',
                                                'processing' => 'bg-info-subtle text-info border border-info-subtle',
                                                'cancelled' => 'bg-danger-subtle text-danger border border-danger-subtle',
                                                default => 'bg-warning-subtle text-warning border border-warning-subtle'
                                            };
                                            ?>
                                            <span class="badge <?php echo $status_class; ?> px-2 py-1 rounded-2"><?php echo ucfirst($order['status']); ?></span>
                                        </td>
                                        <td>
                                            <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-light text-primary hover-lift"><i class="fas fa-eye"></i> View</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- Chart.js Script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('salesChart').getContext('2d');
    const salesChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($dates); ?>,
            datasets: [{
                label: 'Revenue (₹)',
                data: <?php echo json_encode($sales_data); ?>,
                borderColor: '#2A6B42',
                backgroundColor: 'rgba(42, 107, 66, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#ffffff',
                pointBorderColor: '#2A6B42',
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { borderDash: [5, 5] },
                    ticks: {
                        callback: function(value) { return '₹' + value; }
                    }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
</script>
