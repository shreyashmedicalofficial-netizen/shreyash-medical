<?php
include '../config/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';

$role = $_SESSION['role'];
$branch_id = $_SESSION['branch_id'] ?? null;

// Role & Branch Logic
if ($_SESSION['role'] === 'admin' && empty($_SESSION['branch_id']) && isset($_GET['branch_view'])) {
    $branch_id = $_GET['branch_view'];
}

// Filters
$status_filter = $_GET['status'] ?? '';
$date_filter = $_GET['date'] ?? '';

// Build Query
$where_clauses = [];
$params = [];

if (!empty($branch_id)) {
    $where_clauses[] = "o.branch_id = ?";
    $params[] = $branch_id;
}

if ($status_filter) {
    $where_clauses[] = "o.status = ?";
    $params[] = $status_filter;
}

if ($date_filter) {
    $where_clauses[] = "DATE(o.order_date) = ?";
    $params[] = $date_filter;
}

$where_sql = $where_clauses ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

$sql = "SELECT o.*, u.fullname, b.name as branch_name 
        FROM orders o 
        JOIN users u ON o.user_id = u.id 
        LEFT JOIN branches b ON o.branch_id = b.id 
        $where_sql 
        ORDER BY o.order_date DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $orders = $stmt->fetchAll();
} catch (PDOException $e) {
    $orders = [];
    error_log("Orders Fetch Error: " . $e->getMessage());
}
?>

<div class="main-content">
    <?php include 'includes/topbar.php'; ?>

    <div class="container-fluid p-4">
        <div class="card border-0 shadow-sm mb-4 rounded-4">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0 text-dark">Order Management</h5>
                    <form class="d-flex gap-2" method="GET">
                        <input type="date" name="date" class="form-control form-control-sm" value="<?php echo htmlspecialchars($date_filter); ?>">
                        <select name="status" class="form-select form-select-sm w-auto">
                            <option value="">All Statuses</option>
                            <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="processing" <?php echo $status_filter == 'processing' ? 'selected' : ''; ?>>Processing</option>
                            <option value="completed" <?php echo $status_filter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="cancelled" <?php echo $status_filter == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                        <button type="submit" class="btn btn-sm btn-primary-custom">Filter</button>
                        <?php if($status_filter || $date_filter): ?>
                            <a href="orders.php" class="btn btn-sm btn-outline-secondary">Reset</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <div class="table-card">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Order ID</th>
                            <th>Customer</th>
                            <?php if($role === 'admin'): ?><th>Branch</th><?php endif; ?>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($orders)): ?>
                            <tr>
                                <td colspan="<?php echo $role === 'admin' ? 7 : 6; ?>" class="text-center py-5">
                                    <div class="text-muted">
                                        <i class="fas fa-shopping-basket fa-3x mb-3 opacity-25"></i>
                                        <p class="mb-0">No orders found.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($orders as $order): ?>
                            <tr>
                                <td class="ps-4 fw-bold text-primary">#<?php echo $order['id']; ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm bg-light rounded-circle d-flex align-items-center justify-content-center me-2 text-primary fw-bold" style="width: 32px; height: 32px;">
                                            <?php echo strtoupper(substr($order['fullname'], 0, 1)); ?>
                                        </div>
                                        <div>
                                            <div class="fw-bold"><?php echo htmlspecialchars($order['fullname']); ?></div>
                                            <small class="text-muted" style="font-size: 0.75rem;">View Profile</small>
                                        </div>
                                    </div>
                                </td>
                                <?php if($role === 'admin'): ?>
                                    <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($order['branch_name'] ?? 'N/A'); ?></span></td>
                                <?php endif; ?>
                                <td>
                                    <div class="fw-medium"><?php echo date('M d, Y', strtotime($order['order_date'])); ?></div>
                                    <small class="text-muted"><?php echo date('h:i A', strtotime($order['order_date'])); ?></small>
                                </td>
                                <td class="fw-bold">₹<?php echo number_format($order['total_amount']); ?></td>
                                <td>
                                    <?php 
                                    $status_class = match($order['status']) {
                                        'completed' => 'bg-success-subtle text-success border border-success-subtle',
                                        'processing' => 'bg-info-subtle text-info border border-info-subtle',
                                        'cancelled' => 'bg-danger-subtle text-danger border border-danger-subtle',
                                        default => 'bg-warning-subtle text-warning border border-warning-subtle'
                                    };
                                    ?>
                                    <span class="badge <?php echo $status_class; ?> px-2 py-1 rounded-2"><?php echo ucfirst($order['status']); ?></span>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-light border-0 text-muted" data-bs-toggle="dropdown">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                            <li><h6 class="dropdown-header text-uppercase small fw-bold">Update Status</h6></li>
                                            <li><form action="api/order_action.php" method="POST" class="d-inline">
                                                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                <input type="hidden" name="action" value="update_status">
                                                <input type="hidden" name="status" value="processing">
                                                <button type="submit" class="dropdown-item"><i class="fas fa-spinner me-2 text-info"></i> Mark Processing</button>
                                            </form></li>
                                            <li><form action="api/order_action.php" method="POST" class="d-inline">
                                                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                <input type="hidden" name="action" value="update_status">
                                                <input type="hidden" name="status" value="completed">
                                                <button type="submit" class="dropdown-item"><i class="fas fa-check-circle me-2 text-success"></i> Mark Completed</button>
                                            </form></li>
                                            <li><form action="api/order_action.php" method="POST" class="d-inline">
                                                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                <input type="hidden" name="action" value="update_status">
                                                <input type="hidden" name="status" value="cancelled">
                                                <button type="submit" class="dropdown-item"><i class="fas fa-times-circle me-2 text-danger"></i> Cancel Order</button>
                                            </form></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item" href="order_details.php?id=<?php echo $order['id']; ?>"><i class="fas fa-eye me-2 text-primary"></i> View Details</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
