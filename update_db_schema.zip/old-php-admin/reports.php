<?php
include '../config/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';


// --- Filter Logic ---
$role = $_SESSION['role'];
$branch_id = $_SESSION['branch_id'] ?? null;

// Filter Parameters
$filter_type = $_GET['filter_type'] ?? 'year'; // year, month, range
$selected_year = $_GET['year'] ?? date('Y');
$selected_month = $_GET['month'] ?? date('m');
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');

// Super Admin Branch Filter
if ($role === 'admin' && empty($branch_id) && isset($_GET['branch_view']) && !empty($_GET['branch_view'])) {
    $branch_id = $_GET['branch_view'];
}

// Build SQL Conditions
$where_clauses = ["o.status != 'cancelled'"];
if (!empty($branch_id)) {
    $where_clauses[] = "o.branch_id = $branch_id";
}

// Date Filters
$chart_labels = [];
$chart_data = [];
$chart_title = "";

if ($filter_type === 'month') {
    $where_clauses[] = "YEAR(o.order_date) = $selected_year AND MONTH(o.order_date) = $selected_month";
    $chart_title = "Daily Sales (" . date('F Y', mktime(0, 0, 0, $selected_month, 10)) . ")";
    
    // Group by Day
    $days_in_month = cal_days_in_month(CAL_GREGORIAN, $selected_month, $selected_year);
    $sales_map = array_fill(1, $days_in_month, 0);
    
    $sales_query = "SELECT DAY(order_date) as day, SUM(total_amount) as total 
                    FROM orders o WHERE " . implode(' AND ', $where_clauses) . " 
                    GROUP BY day";
    
    $stmt = $pdo->query($sales_query);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $sales_map[$row['day']] = $row['total'];
    }

    // Limit graph to today if current month
    $limit_day = ($selected_year == date('Y') && $selected_month == date('m')) ? date('j') : $days_in_month;
    
    for ($i = 1; $i <= $limit_day; $i++) {
        $chart_labels[] = $i;
        $chart_data[] = $sales_map[$i];
    }

} elseif ($filter_type === 'range') {
    $where_clauses[] = "DATE(o.order_date) BETWEEN '$start_date' AND '$end_date'";
    $chart_title = "Sales from $start_date to $end_date";

    // Show daily breakdown
    $sales_query = "SELECT DATE(order_date) as date, SUM(total_amount) as total 
                    FROM orders o WHERE " . implode(' AND ', $where_clauses) . " 
                    GROUP BY date ORDER BY date ASC";
    
    $stmt = $pdo->query($sales_query);
    $sales_raw = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // Date => Total
    
    $current = strtotime($start_date);
    $end = strtotime($end_date);
    
    while ($current <= $end) {
        $d = date('Y-m-d', $current);
        // Don't show future dates
        if (strtotime($d) > time()) break;

        $chart_labels[] = date('M d', $current);
        $chart_data[] = $sales_raw[$d] ?? 0;
        $current = strtotime('+1 day', $current);
    }

} else {
    // Default: This Year
    $where_clauses[] = "YEAR(o.order_date) = $selected_year";
    $chart_title = "Monthly Sales ($selected_year)";
    
    $sales_map = array_fill(1, 12, 0);
    $sales_query = "SELECT MONTH(order_date) as month, SUM(total_amount) as total 
                    FROM orders o WHERE " . implode(' AND ', $where_clauses) . " 
                    GROUP BY month";
    
    $stmt = $pdo->query($sales_query);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $sales_map[$row['month']] = $row['total'];
    }

    // Limit to current month if current year
    $limit_month = ($selected_year == date('Y')) ? date('n') : 12;
    $month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    for ($i = 1; $i <= $limit_month; $i++) {
        $chart_labels[] = $month_names[$i-1];
        $chart_data[] = $sales_map[$i];
    }
}

$where_sql = implode(' AND ', $where_clauses);

// 2. Top Selling Products (Filtered)
$top_products = [];
$top_counts = [];
$prod_query = "
    SELECT p.name, SUM(oi.quantity) as sold 
    FROM order_items oi 
    JOIN orders o ON oi.order_id = o.id 
    JOIN products p ON oi.product_id = p.id 
    WHERE $where_sql
    GROUP BY oi.product_id 
    ORDER BY sold DESC 
    LIMIT 5";
$stmt = $pdo->query($prod_query);
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $top_products[] = $row['name']; // Truncate manually in JS if needed
    $top_counts[] = $row['sold'];
}

// 3. Recent Transactions (Filtered)
$recent_query = "
    SELECT o.*, u.fullname 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    WHERE $where_sql
    ORDER BY o.order_date DESC 
    LIMIT 10";
$recent_orders = $pdo->query($recent_query)->fetchAll();

// Fetch Branches for Super Admin
$branches = ($role === 'admin') ? $pdo->query("SELECT id, name FROM branches")->fetchAll() : [];
?>

<div class="main-content">
    <?php include 'includes/topbar.php'; ?>

    <div class="container-fluid p-4">
        <!-- Filter Section -->
        <div class="card border-0 shadow-sm mb-4 rounded-4">
            <div class="card-body p-3">
                <form method="GET" class="row g-2 align-items-end">
                    <!-- Branch Filter (Admin Only) -->
                    <?php if($role === 'admin'): ?>
                    <div class="col-md-3">
                        <label class="small fw-bold text-muted">Branch</label>
                        <select name="branch_view" class="form-select form-select-sm">
                            <option value="">All Branches</option>
                            <?php foreach($branches as $b): ?>
                                <option value="<?php echo $b['id']; ?>" <?php echo $branch_id == $b['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($b['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <div class="col-md-2">
                        <label class="small fw-bold text-muted">Filter Type</label>
                        <select name="filter_type" class="form-select form-select-sm" id="filterType" onchange="toggleFilters()">
                            <option value="year" <?php echo $filter_type == 'year' ? 'selected' : ''; ?>>Yearly</option>
                            <option value="month" <?php echo $filter_type == 'month' ? 'selected' : ''; ?>>Monthly</option>
                            <option value="range" <?php echo $filter_type == 'range' ? 'selected' : ''; ?>>Date Range</option>
                        </select>
                    </div>

                    <!-- Year Select -->
                    <div class="col-md-2 filter-group group-year group-month">
                        <label class="small fw-bold text-muted">Year</label>
                        <select name="year" class="form-select form-select-sm">
                            <?php for($y=date('Y'); $y>=2024; $y--): ?>
                                <option value="<?php echo $y; ?>" <?php echo $selected_year == $y ? 'selected' : ''; ?>><?php echo $y; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <!-- Month Select -->
                    <div class="col-md-2 filter-group group-month" style="display:none;">
                        <label class="small fw-bold text-muted">Month</label>
                        <select name="month" class="form-select form-select-sm">
                            <?php for($m=1; $m<=12; $m++): ?>
                                <option value="<?php echo $m; ?>" <?php echo $selected_month == $m ? 'selected' : ''; ?>>
                                    <?php echo date('F', mktime(0, 0, 0, $m, 10)); ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <!-- Date Range -->
                    <div class="col-md-3 filter-group group-range" style="display:none;">
                        <label class="small fw-bold text-muted">Start Date</label>
                        <input type="date" name="start_date" class="form-control form-control-sm" value="<?php echo $start_date; ?>">
                    </div>
                    <div class="col-md-3 filter-group group-range" style="display:none;">
                        <label class="small fw-bold text-muted">End Date</label>
                        <input type="date" name="end_date" class="form-control form-control-sm" value="<?php echo $end_date; ?>">
                    </div>

                    <div class="col-md-auto">
                        <button type="submit" class="btn btn-sm btn-primary-custom w-100"><i class="fas fa-filter me-1"></i> Apply</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-8">
                <div class="stat-card h-100">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="fw-bold mb-0"><?php echo $chart_title; ?></h5>
                    </div>
                    <div style="height: 300px; position: relative;">
                        <canvas id="salesChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card h-100">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="fw-bold mb-0">Top Products</h5>
                    </div>
                    <div style="height: 250px; display: flex; justify-content: center;">
                        <canvas id="productsChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="table-card">
            <div class="table-header">
                <div>
                    <h5 class="mb-0 fw-bold">Transactions</h5>
                    <small class="text-muted">Filtered results</small>
                </div>
                <button class="btn btn-sm btn-light disabled">Export</button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($recent_orders)): ?>
                            <tr><td colspan="5" class="text-center py-5 text-muted">No transactions found for this period.</td></tr>
                        <?php else: ?>
                            <?php foreach($recent_orders as $order): ?>
                                <tr>
                                    <td class="ps-4 text-muted small"><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                                    <td class="fw-bold text-primary">#<?php echo $order['id']; ?></td>
                                    <td><?php echo htmlspecialchars($order['fullname']); ?></td>
                                    <td class="fw-bold">₹<?php echo number_format($order['total_amount']); ?></td>
                                    <td>
                                        <?php 
                                        $badge = match($order['status']) {
                                            'completed' => 'success-subtle text-success border border-success-subtle',
                                            'pending' => 'warning-subtle text-warning border border-warning-subtle',
                                            'cancelled' => 'danger-subtle text-danger border border-danger-subtle',
                                            default => 'info-subtle text-info border border-info-subtle'
                                        };
                                        ?>
                                        <span class="badge bg-<?php echo $badge; ?>"><?php echo ucfirst($order['status']); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
function toggleFilters() {
    const type = document.getElementById('filterType').value;
    document.querySelectorAll('.filter-group').forEach(el => el.style.display = 'none');
    
    if (type === 'year') {
        document.querySelectorAll('.group-year').forEach(el => el.style.display = 'block');
    } else if (type === 'month') {
        document.querySelectorAll('.group-month').forEach(el => el.style.display = 'block');
    } else if (type === 'range') {
        document.querySelectorAll('.group-range').forEach(el => el.style.display = 'block');
    }
}
// Init Logic
toggleFilters();

document.addEventListener('DOMContentLoaded', function() {
    // Sales Chart
    const ctx1 = document.getElementById('salesChart').getContext('2d');
    new Chart(ctx1, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($chart_labels); ?>,
            datasets: [{
                label: 'Sales (₹)',
                data: <?php echo json_encode($chart_data); ?>,
                borderColor: '#2A6B42',
                tension: 0.3,
                fill: true,
                backgroundColor: 'rgba(42, 107, 66, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: '#ffffff',
                pointBorderColor: '#2A6B42',
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, grid: { borderDash: [5, 5] } },
                x: { grid: { display: false } }
            }
        }
    });

    // Products Chart
    const ctx2 = document.getElementById('productsChart').getContext('2d');
    const productLabels = <?php echo json_encode($top_products); ?>;
    const productData = <?php echo json_encode($top_counts); ?>;

    if (productLabels.length === 0) {
        ctx2.font = "14px Arial";
        ctx2.textAlign = "center";
        ctx2.fillText("No data for this period", 150, 125);
    } else {
        new Chart(ctx2, {
            type: 'doughnut',
            data: {
                labels: productLabels,
                datasets: [{
                    data: productData,
                    backgroundColor: ['#2A6B42', '#FFC107', '#212529', '#198754', '#6c757d'],
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { 
                    legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 10, padding: 20 } } 
                },
                cutout: '65%'
            }
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>
