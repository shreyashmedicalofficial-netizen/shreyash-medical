<?php
include '../config/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';

$branch_id = $_SESSION['branch_id'] ?? null;
$role = $_SESSION['role'];

// Handle different scenarios:
// 1. Admin sees everything or can filter by branch
// 2. Manager sees only their branch inventory

if ($role === 'admin' && empty($branch_id) && isset($_GET['branch_view'])) {
    $branch_id = $_GET['branch_view'];
}

    if (empty($branch_id)) {
    // Super Admin View (Global)
    $query = "
        SELECT p.id as product_id, p.name, p.sku, p.category, p.price, p.image, p.description,
               b.name as branch_name, i.quantity, i.id as inventory_id, i.branch_id
        FROM products p
        LEFT JOIN inventory i ON p.id = i.product_id
        LEFT JOIN branches b ON i.branch_id = b.id
        ORDER BY p.name ASC
    ";
} else {
    // Specific Branch View
    $query = "
        SELECT p.id as product_id, p.name, p.sku, p.category, p.price, p.image, p.description,
               'Current Branch' as branch_name, COALESCE(i.quantity, 0) as quantity, i.id as inventory_id, $branch_id as branch_id
        FROM products p
        LEFT JOIN inventory i ON p.id = i.product_id AND i.branch_id = $branch_id
        ORDER BY p.name ASC
    ";
}

try {
    $inventory_items = $pdo->query($query)->fetchAll();
} catch(Exception $e) {
    $inventory_items = [];
}
?>

<div class="main-content">
    <?php include 'includes/topbar.php'; ?>

    <div class="container-fluid p-4">
        <?php if(isset($_GET['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm border-0" role="alert">
                <i class="fas fa-check-circle me-2"></i> <?php echo htmlspecialchars($_GET['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(isset($_GET['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i> <?php echo htmlspecialchars($_GET['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-0">Inventory Management</h2>
            <div class="d-flex gap-2">
                <input type="text" class="form-control" placeholder="Search products..." style="width: 250px;">
                <?php if($role === 'admin'): ?>
                    <button class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#addProductModal"><i class="fas fa-plus me-2"></i> Add New</button>
                <?php endif; ?>
            </div>
        </div>

        <div class="table-card">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Product</th>
                            <th>SKU</th>
                            <th>Category</th>
                            <th>Price</th>
                            <?php if($role === 'admin'): ?><th>Branch</th><?php endif; ?>
                            <th>Stock Level</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($inventory_items as $item): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <?php 
                                        $imgSrc = !empty($item['image']) ? (strpos($item['image'], 'http') === 0 ? $item['image'] : '../assets/images/products/'.$item['image']) : '';
                                        if(empty($imgSrc)) {
                                            $imgSrc = 'https://ui-avatars.com/api/?name='.urlencode($item['name']).'&background=random&color=fff&size=40';
                                        }
                                    ?>
                                    <img src="<?php echo $imgSrc; ?>" class="rounded-3 border me-3" width="40" height="40" style="object-fit: cover;">
                                        <span class="fw-bold"><?php echo htmlspecialchars($item['name']); ?></span>
                                    </div>
                                </td>
                                <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($item['sku']); ?></span></td>
                                <td><?php echo htmlspecialchars($item['category'] ?? 'N/A'); ?></td>
                                <td>₹<?php echo number_format($item['price'], 2); ?></td>
                                <?php if($role === 'admin'): ?>
                                    <td><span class="badge bg-secondary-subtle text-dark"><?php echo htmlspecialchars($item['branch_name'] ?? 'Unassigned'); ?></span></td>
                                <?php endif; ?>
                                <td class="fw-bold fs-6">
                                    <?php echo $item['quantity']; ?>
                                </td>
                                <td>
                                    <?php if($item['quantity'] > 50): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle">In Stock</span>
                                    <?php elseif($item['quantity'] > 10): ?>
                                        <span class="badge bg-warning-subtle text-warning border border-warning-subtle">Low Stock</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle">Critical</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary" 
                                                title="Update Stock"
                                                onclick="updateStock(<?php echo $item['product_id']; ?>, <?php echo $item['quantity'] ?? 0; ?>, '<?php echo htmlspecialchars($item['name'], ENT_QUOTES); ?>', <?php echo $item['branch_id'] ?? ($_SESSION['branch_id'] ?? $branch_id); ?>)">
                                            <i class="fas fa-boxes"></i> Stock
                                        </button>
                                        <?php if($role === 'admin'): ?>
                                        <button class="btn btn-sm btn-outline-dark" 
                                                title="Edit Product Details"
                                                onclick='editProduct(<?php echo json_encode($item); ?>)'>
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if(empty($inventory_items)): ?>
                            <tr><td colspan="8" class="text-center py-5 text-muted">No inventory found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Product Modal -->
<div class="modal fade" id="addProductModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Add New Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="api/product_action.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add">
                <div class="modal-body pt-4">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Product Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">SKU (Unique ID)</label>
                            <input type="text" class="form-control" name="sku" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Category</label>
                            <select class="form-select" name="category" required>
                                <option value="Medicine">Medicine</option>
                                <option value="Healthcare">Healthcare</option>
                                <option value="Baby Care">Baby Care</option>
                                <option value="Devices">Devices</option>
                                <option value="Safety">Safety</option>
                                <option value="Fitness">Fitness</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Price (₹)</label>
                            <input type="number" step="0.01" class="form-control" name="price" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold small">Description</label>
                            <textarea class="form-control" name="description" rows="2"></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold small">Product Image</label>
                            <input type="file" class="form-control" name="image" accept="image/*">
                            <small class="text-muted">Overwrites existing URL if uploaded.</small>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary-custom">Add Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Product Modal -->
<div class="modal fade" id="editProductModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Edit Product Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="api/product_action.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="product_id" id="edit_product_id">
                <div class="modal-body pt-4">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Product Name</label>
                            <input type="text" class="form-control" name="name" id="edit_name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">SKU</label>
                            <input type="text" class="form-control" name="sku" id="edit_sku" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Category</label>
                            <select class="form-select" name="category" id="edit_category" required>
                                <option value="Medicine">Medicine</option>
                                <option value="Healthcare">Healthcare</option>
                                <option value="Baby Care">Baby Care</option>
                                <option value="Devices">Devices</option>
                                <option value="Safety">Safety</option>
                                <option value="Fitness">Fitness</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Price (₹)</label>
                            <input type="number" step="0.01" class="form-control" name="price" id="edit_price" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold small">Description</label>
                            <textarea class="form-control" name="description" id="edit_description" rows="2"></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold small">Product Image</label>
                            <div class="d-flex align-items-center gap-3 mb-2">
                                <img id="edit_image_preview" src="" alt="Preview" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px; display: none;">
                                <input type="file" class="form-control" name="image" accept="image/*">
                            </div>
                            <small class="text-muted">Leave blank to keep current image.</small>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="action" value="delete" class="btn btn-outline-danger me-auto" onclick="return confirm('Are you sure? This will delete the product everywhere.')">Delete Product</button>
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary-custom">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Update Stock Modal (Existing) -->
<div class="modal fade" id="updateStockModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Update Stock</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="api/inventory_update.php" method="POST">
                <div class="modal-body pt-4">
                    <input type="hidden" name="product_id" id="modal_product_id">
                    <input type="hidden" name="branch_id" id="modal_branch_id">
                    <div class="mb-4">
                        <label class="form-label text-muted small text-uppercase fw-bold">Product</label>
                        <div class="fs-5 fw-bold text-dark" id="modal_product_name"></div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small text-uppercase fw-bold">New Quantity</label>
                        <input type="number" class="form-control form-control-lg" name="quantity" id="modal_quantity" required min="0">
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 pb-4 pe-4">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary-custom px-4">Update Stock</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function updateStock(id, qty, name, branchId) {
    document.getElementById('modal_product_id').value = id;
    document.getElementById('modal_quantity').value = qty;
    document.getElementById('modal_branch_id').value = branchId;
    document.getElementById('modal_product_name').innerText = name;
    new bootstrap.Modal(document.getElementById('updateStockModal')).show();
}

function editProduct(product) {
    document.getElementById('edit_product_id').value = product.product_id;
    document.getElementById('edit_name').value = product.name;
    document.getElementById('edit_sku').value = product.sku;
    document.getElementById('edit_category').value = product.category;
    document.getElementById('edit_price').value = product.price;
    document.getElementById('edit_description').value = product.description || '';
    
    // Image Preview
    const imgPreview = document.getElementById('edit_image_preview');
    if (product.image) {
        imgPreview.src = product.image.startsWith('http') ? product.image : '../assets/images/products/' + product.image;
        imgPreview.style.display = 'block';
    } else {
        // Show text avatar preview if no image
        imgPreview.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(product.name) + '&background=random&color=fff&size=50';
        imgPreview.style.display = 'block';
    }

    new bootstrap.Modal(document.getElementById('editProductModal')).show();
}
</script>

<?php include 'includes/footer.php'; ?>
