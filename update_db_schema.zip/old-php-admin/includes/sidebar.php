<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!-- Mobile Overlay -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

<!-- Sidebar -->
<aside class="sidebar" id="adminSidebar">
    <div class="sidebar-header">
        <a href="index.php" class="sidebar-brand">
            <i class="fas fa-heartbeat text-warning"></i>
            <span>Shreyash Admin</span>
        </a>
    </div>
    
    <div class="sidebar-nav">
        <div class="nav-category">Main</div>
        <a href="index.php" class="nav-link <?php echo $current_page == 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
        
        <?php if($_SESSION['role'] === 'admin' && empty($_SESSION['branch_id'])): ?>
        <div class="nav-category">Super Admin</div>
        <a href="stores.php" class="nav-link <?php echo $current_page == 'stores.php' ? 'active' : ''; ?>">
            <i class="fas fa-store"></i> Manage Stores
        </a>
        <?php endif; ?>
        
        <div class="nav-category">Management</div>
        <a href="inventory.php" class="nav-link <?php echo $current_page == 'inventory.php' ? 'active' : ''; ?>">
            <i class="fas fa-boxes"></i> Inventory
        </a>
        <a href="users.php" class="nav-link <?php echo $current_page == 'users.php' ? 'active' : ''; ?>">
            <i class="fas fa-users"></i> Users
        </a>
        <a href="stock_requests.php" class="nav-link <?php echo $current_page == 'stock_requests.php' ? 'active' : ''; ?>">
            <i class="fas fa-truck-loading"></i> Stock Requests
        </a>
        <a href="orders.php" class="nav-link <?php echo $current_page == 'orders.php' ? 'active' : ''; ?>">
            <i class="fas fa-shopping-bag"></i> Orders
        </a>
        
        <div class="nav-category">Analytics</div>
        <a href="reports.php" class="nav-link <?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Reports
        </a>
    </div>
    
    <div class="sidebar-footer">
        <div class="user-profile">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['fullname'] ?? 'A', 0, 1)); ?>
            </div>
            <div class="user-info text-white">
                <div class="fw-bold" style="font-size: 0.9rem;"><?php echo htmlspecialchars($_SESSION['fullname'] ?? 'Admin'); ?></div>
                <small class="text-white-50" style="font-size: 0.75rem;"><?php echo ucfirst($_SESSION['role'] ?? 'Admin'); ?></small>
            </div>
        </div>
        <a href="../logout.php" class="d-block mt-3 text-white-50 text-decoration-none hover-white">
            <i class="fas fa-sign-out-alt me-2"></i> Logout
        </a>
    </div>
</aside>
