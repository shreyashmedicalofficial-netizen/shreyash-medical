<header class="topbar">
    <button class="btn btn-link text-dark d-lg-none" onclick="document.getElementById('adminSidebar').classList.toggle('active'); document.getElementById('sidebarOverlay').classList.toggle('show');">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="d-flex align-items-center">
        <h5 class="page-title">
            <?php 
                $page = basename($_SERVER['PHP_SELF'], '.php');
                echo ucfirst(str_replace('_', ' ', $page)); 
            ?>
        </h5>
        <!-- Context Badge -->
        <?php if($_SESSION['role'] === 'manager' && isset($_SESSION['branch_name'])): ?>
            <span class="badge bg-success-subtle text-success ms-3 border border-success-subtle">
                <i class="fas fa-store me-1"></i> <?php echo htmlspecialchars($_SESSION['branch_name']); ?>
            </span>
        <?php elseif($_SESSION['role'] === 'admin'): ?>
            <span class="badge bg-primary-subtle text-primary ms-3 border border-primary-subtle">
                <i class="fas fa-shield-alt me-1"></i> Super Admin
            </span>
        <?php endif; ?>
    </div>

    <div class="d-flex align-items-center gap-3">
        <!-- Notifications -->
        <?php
        // Fetch Unread Notifications
        $unread_stmt = $pdo->query("SELECT * FROM notifications WHERE is_read = 0 ORDER BY created_at DESC LIMIT 5");
        $notifications = $unread_stmt->fetchAll();
        $unread_count = count($notifications);
        ?>
        <div class="dropdown">
            <a href="#" class="text-dark position-relative" data-bs-toggle="dropdown">
                <i class="far fa-bell fa-lg text-secondary"></i>
                <?php if($unread_count > 0): ?>
                <span class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle">
                    <span class="visually-hidden">New alerts</span>
                </span>
                <?php endif; ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 mt-2" style="width: 320px;">
                <li><h6 class="dropdown-header text-uppercase small fw-bold d-flex justify-content-between align-items-center">
                    Notifications
                    <?php if($unread_count > 0): ?>
                    <span class="badge bg-danger rounded-pill"><?php echo $unread_count; ?> New</span>
                    <?php endif; ?>
                </h6></li>
                <?php if($unread_count > 0): ?>
                    <?php foreach($notifications as $notif): ?>
                    <li>
                        <a class="dropdown-item small py-2 d-flex align-items-start gap-2" href="#" onclick="markRead(<?php echo $notif['id']; ?>)">
                            <div class="mt-1"><i class="fas fa-circle text-primary" style="font-size: 8px;"></i></div>
                            <div>
                                <div class="text-dark fw-medium"><?php echo htmlspecialchars($notif['message']); ?></div>
                                <div class="text-muted" style="font-size: 0.75rem;"><?php echo date('M d, h:i A', strtotime($notif['created_at'])); ?></div>
                            </div>
                        </a>
                    </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <li><div class="dropdown-item small text-muted text-center py-3">No new notifications</div></li>
                <?php endif; ?>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item small text-center text-primary fw-bold" href="#">View All Notifications</a></li>
            </ul>
        </div>

        <script>
        function markRead(id) {
            fetch('api/mark_notification_read.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + id
            }).then(() => location.reload()); 
        }
        </script>
        
        <!-- User Menu -->
        <div class="dropdown">
            <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                 <div class="user-avatar" style="width: 35px; height: 35px; background: #e9ecef; color: var(--admin-primary);">
                    <?php echo strtoupper(substr($_SESSION['fullname'] ?? 'A', 0, 1)); ?>
                </div>
            </a>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 mt-2">
                <li><a class="dropdown-item" href="../index.php"><i class="fas fa-external-link-alt me-2 text-muted"></i> Visit Website</a></li>
                <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-circle me-2 text-muted"></i> Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</header>
