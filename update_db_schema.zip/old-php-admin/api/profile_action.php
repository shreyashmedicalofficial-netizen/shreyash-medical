<?php
session_start();
include '../../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    try {
        if (!empty($password)) {
            // Update with password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET fullname = ?, email = ?, phone = ?, password = ? WHERE id = ?");
            $stmt->execute([$fullname, $email, $phone, $hashed_password, $user_id]);
        } else {
            // Update without password
            $stmt = $pdo->prepare("UPDATE users SET fullname = ?, email = ?, phone = ? WHERE id = ?");
            $stmt->execute([$fullname, $email, $phone, $user_id]);
        }
        
        // Update Session
        $_SESSION['fullname'] = $fullname;
        
        header("Location: ../profile.php?success=1");
        exit;
    } catch (PDOException $e) {
        // Handle unique email error etc
        header("Location: ../profile.php?error=" . urlencode($e->getMessage()));
        exit;
    }
}
?>
