<?php
session_start();
include '../../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];
    
    // Use branch_id from POST (if Admin) or fallback to Session (if Manager)
    $branch_id = $_POST['branch_id'] ?? $_SESSION['branch_id'];
    
    if (!$branch_id) {
        $branch_id = 1; // Fallback
    }

    try {
        // Check if entry exists
        $stmt = $pdo->prepare("SELECT id FROM inventory WHERE branch_id = ? AND product_id = ?");
        $stmt->execute([$branch_id, $product_id]);
        
        if ($stmt->fetch()) {
            // Update
            $stmt = $pdo->prepare("UPDATE inventory SET quantity = ? WHERE branch_id = ? AND product_id = ?");
            $stmt->execute([$quantity, $branch_id, $product_id]);
        } else {
            // Insert
            $stmt = $pdo->prepare("INSERT INTO inventory (branch_id, product_id, quantity) VALUES (?, ?, ?)");
            $stmt->execute([$branch_id, $product_id, $quantity]);
        }
        
        header("Location: ../inventory.php?success=Stock updated");
    } catch (PDOException $e) {
        header("Location: ../inventory.php?error=Update failed: " . $e->getMessage());
    }
}
?>
