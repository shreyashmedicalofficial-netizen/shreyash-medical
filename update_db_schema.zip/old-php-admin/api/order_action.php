<?php
session_start();
include '../../config/db.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager')) {
    header("Location: ../../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_status') {
        $order_id = $_POST['order_id'];
        $status = $_POST['status'];
        
        // Validate Status
        $allowed_statuses = ['pending', 'processing', 'completed', 'cancelled'];
        if (!in_array($status, $allowed_statuses)) {
             header("Location: ../orders.php?error=Invalid status");
             exit;
        }

        // Check permission (Manager can only update their branch orders)
        if ($_SESSION['role'] === 'manager') {
            $stmt = $pdo->prepare("SELECT branch_id FROM orders WHERE id = ?");
            $stmt->execute([$order_id]);
            $order_branch = $stmt->fetchColumn();
            
            if ($order_branch != $_SESSION['branch_id']) {
                header("Location: ../orders.php?error=Unauthorized access");
                exit;
            }
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
            $stmt->execute([$status, $order_id]);
            
            header("Location: ../orders.php?success=Order status updated to " . ucfirst($status));
            exit;
        } catch (PDOException $e) {
            header("Location: ../orders.php?error=Failed to update order");
            exit;
        }
    }
}
?>
