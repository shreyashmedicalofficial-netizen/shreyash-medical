<?php
session_start();
include '../../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'create') {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $branch_id = !empty($_POST['branch_id']) ? $_POST['branch_id'] : NULL;

    try {
        $stmt = $pdo->prepare("INSERT INTO users (fullname, email, phone, password, role, branch_id) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$fullname, $email, $phone, $password, $role, $branch_id]);
        header("Location: ../users.php?success=User created");
    } catch (PDOException $e) {
        header("Location: ../users.php?error=Failed to create user: " . $e->getMessage());
    }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'edit') {
    $id = $_POST['user_id'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $role = $_POST['role'];
    $branch_id = !empty($_POST['branch_id']) ? $_POST['branch_id'] : NULL;

    try {
        // Update basic info
        $sql = "UPDATE users SET fullname = ?, email = ?, phone = ?, role = ?, branch_id = ? WHERE id = ?";
        $params = [$fullname, $email, $phone, $role, $branch_id, $id];
        
        // Update password if provided
        if (!empty($_POST['password'])) {
            $sql = "UPDATE users SET fullname = ?, email = ?, phone = ?, role = ?, branch_id = ?, password = ? WHERE id = ?";
            $params[] = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $params[] = $id; // User ID at end
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        header("Location: ../users.php?success=User updated");
    } catch (PDOException $e) {
        header("Location: ../users.php?error=Failed to update user: " . $e->getMessage());
    }

} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'delete') {
    $id = $_POST['user_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        header("Location: ../users.php?success=User deleted");
    } catch (PDOException $e) {
        header("Location: ../users.php?error=Failed to delete user: " . $e->getMessage());
    }
}
?>
