<?php
session_start();
include '../../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit;
}

$branch_id = $_SESSION['branch_id'] ?? 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'create') {
        $product_id = $_POST['product_id'];
        $provider_branch_id = $_POST['provider_branch_id'];
        $quantity = $_POST['quantity'];

        try {
            $stmt = $pdo->prepare("INSERT INTO stock_requests (requester_branch_id, provider_branch_id, product_id, quantity) VALUES (?, ?, ?, ?)");
            $stmt->execute([$branch_id, $provider_branch_id, $product_id, $quantity]);
            header("Location: ../stock_requests.php?success=Request sent");
        } catch (PDOException $e) {
            header("Location: ../stock_requests.php?error=Request failed");
        }

    } elseif ($action === 'approve' || $action === 'reject') {
        $request_id = $_POST['request_id'];
        $status = ($action === 'approve') ? 'approved' : 'rejected';

        // Start Transaction for accurate stock transfer
        $pdo->beginTransaction();

        try {
            // Update Request Status
            $stmt = $pdo->prepare("UPDATE stock_requests SET status = ?, processed_at = NOW() WHERE id = ?");
            $stmt->execute([$status, $request_id]);

            if ($status === 'approved') {
                // Get Request Details
                $req = $pdo->query("SELECT * FROM stock_requests WHERE id = $request_id")->fetch();

                // Validation: Check if provider has enough stock
                $stmt_check = $pdo->prepare("SELECT quantity FROM inventory WHERE branch_id = ? AND product_id = ?");
                $stmt_check->execute([$branch_id, $req['product_id']]); // $branch_id is current user (provider)
                $current_stock = $stmt_check->fetchColumn();

                if ($current_stock < $req['quantity']) {
                    throw new Exception("Insufficient stock to fulfill request. Available: $current_stock");
                }

                // 1. Deduct from Provider (Current User)
                $deduct = $pdo->prepare("UPDATE inventory SET quantity = quantity - ? WHERE branch_id = ? AND product_id = ?");
                $deduct->execute([$req['quantity'], $branch_id, $req['product_id']]);

                // 2. Add to Requester
                // Check if requester has entry
                $check = $pdo->prepare("SELECT id FROM inventory WHERE branch_id = ? AND product_id = ?");
                $check->execute([$req['requester_branch_id'], $req['product_id']]);
                
                if ($check->fetch()) {
                    $add = $pdo->prepare("UPDATE inventory SET quantity = quantity + ? WHERE branch_id = ? AND product_id = ?");
                    $add->execute([$req['quantity'], $req['requester_branch_id'], $req['product_id']]);
                } else {
                    $insert = $pdo->prepare("INSERT INTO inventory (branch_id, product_id, quantity) VALUES (?, ?, ?)");
                    $insert->execute([$req['requester_branch_id'], $req['product_id'], $req['quantity']]);
                }
            }

            $pdo->commit();
            header("Location: ../stock_requests.php?success=Request $status");
        } catch (Exception $e) {
            $pdo->rollBack();
            header("Location: ../stock_requests.php?error=Action failed: " . $e->getMessage());
        }
    }
}
?>
