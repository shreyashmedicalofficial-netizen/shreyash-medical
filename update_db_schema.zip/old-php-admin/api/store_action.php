<?php
session_start();
include '../../config/db.php';

// Access Control
if ($_SESSION['role'] !== 'admin' || !empty($_SESSION['branch_id'])) {
    header("Location: ../index.php");
    exit;
}

$action = $_REQUEST['action'] ?? '';

try {
    if ($action === 'create') {
        $stmt = $pdo->prepare("INSERT INTO branches (name, address, phone, email, is_active) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $_POST['name'],
            $_POST['address'],
            $_POST['phone'],
            $_POST['email'],
            isset($_POST['is_active']) ? 1 : 0
        ]);
        $msg = "Store created successfully!";

    } elseif ($action === 'update') {
        $stmt = $pdo->prepare("UPDATE branches SET name=?, address=?, phone=?, email=?, is_active=? WHERE id=?");
        $stmt->execute([
            $_POST['name'],
            $_POST['address'],
            $_POST['phone'],
            $_POST['email'],
            isset($_POST['is_active']) ? 1 : 0,
            $_POST['id']
        ]);
        $msg = "Store updated successfully!";

    } elseif ($action === 'delete') {
        $id = $_GET['id'];
        // Check for dependencies (users, orders) before deleting?
        // For now, simple delete
        $stmt = $pdo->prepare("DELETE FROM branches WHERE id = ?");
        $stmt->execute([$id]);
        $msg = "Store deleted successfully!";
    }

    header("Location: ../stores.php?msg=" . urlencode($msg));
    exit;

} catch (PDOException $e) {
    header("Location: ../stores.php?error=" . urlencode($e->getMessage()));
    exit;
}
?>
