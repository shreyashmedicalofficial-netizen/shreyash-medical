<?php
include '../../config/db.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="shreyash_report_' . date('Y-m-d') . '.csv"');

$output = fopen('php://output', 'w');

// Header Row
fputcsv($output, ['Report Generated', date('Y-m-d H:i:s')]);
fputcsv($output, []); // Blank line

// Stock Summary
fputcsv($output, ['Stock Summary']);
fputcsv($output, ['Branch', 'Product', 'Category', 'Quantity', 'Status']);

$stock = $pdo->query("
    SELECT b.name as branch, p.name as product, p.category, i.quantity 
    FROM inventory i 
    JOIN branches b ON i.branch_id = b.id 
    JOIN products p ON i.product_id = p.id
    ORDER BY b.name
")->fetchAll();

foreach ($stock as $row) {
    $status = $row['quantity'] < 10 ? 'Low Stock' : 'In Stock';
    fputcsv($output, [$row['branch'], $row['product'], $row['category'], $row['quantity'], $status]);
}

fputcsv($output, []); // Blank line

// Recent Requests
fputcsv($output, ['Recent Requests']);
fputcsv($output, ['Date', 'Requester', 'Provider', 'Product', 'Quantity', 'Status']);

$requests = $pdo->query("
    SELECT sr.requested_at, b1.name as requester, b2.name as provider, p.name as product, sr.quantity, sr.status 
    FROM stock_requests sr
    JOIN branches b1 ON sr.requester_branch_id = b1.id
    JOIN branches b2 ON sr.provider_branch_id = b2.id
    JOIN products p ON sr.product_id = p.id
    ORDER BY sr.requested_at DESC
    LIMIT 50
")->fetchAll();

foreach ($requests as $row) {
    fputcsv($output, [$row['requested_at'], $row['requester'], $row['provider'], $row['product'], $row['quantity'], $row['status']]);
}

fclose($output);
exit;
?>
