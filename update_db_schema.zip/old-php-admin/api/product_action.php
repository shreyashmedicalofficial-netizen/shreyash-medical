<?php
session_start();
include '../../config/db.php';

// Only Admin can manage products
if ($_SESSION['role'] !== 'admin') {
    header("Location: ../inventory.php?error=Access Denied");
    exit;
}


// ImgBB Upload Function
// ImgBB Upload Function
function uploadToImgBB($file) {
    if (empty($file['tmp_name'])) return null;
    
    $api_key = '4235c428689a930d89ed78ee0c2cf942'; // User provided API key
    $url = 'https://api.imgbb.com/1/upload';
    
    $data = [
        'key' => $api_key,
        'image' => base64_encode(file_get_contents($file['tmp_name']))
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FAILONERROR, true); // Fail on HTTP error
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        error_log("ImgBB Upload Error: " . $error);
        return null;
    }
    
    $result = json_decode($response, true);
    
    if (isset($result['data']['url'])) {
        return $result['data']['url'];
    } else {
        error_log("ImgBB API Error: " . json_encode($result));
    }
    
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Common Fields
    $name = $_POST['name'] ?? '';
    $sku = $_POST['sku'] ?? '';
    $category = $_POST['category'] ?? '';
    $price = $_POST['price'] ?? 0;
    $description = $_POST['description'] ?? '';
    // $image = $_POST['image'] ?? 'https://via.placeholder.com/150'; // Default placeholder

    try {
        if ($action === 'add') {
            $image_url = ''; // Default empty, handled by display logic
            
            // Handle Image Upload
            if (!empty($_FILES['image']['tmp_name'])) {
                $uploaded_url = uploadToImgBB($_FILES['image']);
                if ($uploaded_url) {
                    $image_url = $uploaded_url;
                }
            }

            // Check if SKU exists
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE sku = ?");
            $stmt->execute([$sku]);
            if ($stmt->fetchColumn() > 0) {
                header("Location: ../inventory.php?error=SKU already exists");
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO products (name, sku, category, price, description, image) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $sku, $category, $price, $description, $image_url]);
            
            $pid = $pdo->lastInsertId();
            $branches = $pdo->query("SELECT id FROM branches")->fetchAll(PDO::FETCH_COLUMN);
            $stmt_inv = $pdo->prepare("INSERT INTO inventory (product_id, branch_id, quantity, updated_at) VALUES (?, ?, 0, NOW())");
            foreach ($branches as $bid) {
                $stmt_inv->execute([$pid, $bid]);
            }

            header("Location: ../inventory.php?success=Product Added");

        } elseif ($action === 'edit') {
            $id = $_POST['product_id'];
            
            // Start building update query
            $sql = "UPDATE products SET name = ?, sku = ?, category = ?, price = ?, description = ?";
            $params = [$name, $sku, $category, $price, $description];
            
            // Handle Image Upload if present
            if (!empty($_FILES['image']['tmp_name'])) {
                $uploaded_url = uploadToImgBB($_FILES['image']);
                if ($uploaded_url) {
                    $sql .= ", image = ?";
                    $params[] = $uploaded_url;
                } else {
                    // Upload failed - maybe log it or warn user?
                    // For now, let's just proceed but maybe append a warning to the success message?
                    // Or actually, strictly speaking, if they tried to upload and it failed, we should probably tell them.
                    // But to avoid complex redirect logic right now, I'll log it.
                    error_log("ImgBB Upload Failed for file: " . $_FILES['image']['name']);
                }
            }
            
            $sql .= " WHERE id = ?";
            $params[] = $id;

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            header("Location: ../inventory.php?success=Product Updated");

        } elseif ($action === 'delete') {
             $id = $_POST['product_id'];
             $pdo->prepare("DELETE FROM inventory WHERE product_id = ?")->execute([$id]);
             $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
             header("Location: ../inventory.php?success=Product Deleted");
        }
    } catch (Exception $e) {
        error_log($e->getMessage());
        header("Location: ../inventory.php?error=" . urlencode($e->getMessage()));
    }
}
?>
