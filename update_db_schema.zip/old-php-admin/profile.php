<?php
include '../config/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
?>

<div class="main-content">
    <?php include 'includes/topbar.php'; ?>

    <div class="container-fluid p-4">
        <h2 class="fw-bold mb-4">My Proile</h2>
        
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="card border-0 shadow-sm rounded-4 text-center p-5">
                    <div class="user-avatar mx-auto mb-3 bg-primary-subtle text-primary fw-bold display-4 rounded-circle d-flex align-items-center justify-content-center" style="width: 100px; height: 100px;">
                        <?php echo strtoupper(substr($user['fullname'], 0, 1)); ?>
                    </div>
                    <h4 class="fw-bold"><?php echo htmlspecialchars($user['fullname']); ?></h4>
                    <p class="text-muted"><?php echo htmlspecialchars($user['email']); ?></p>
                    <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2 rounded-pill"><?php echo ucfirst($user['role']); ?></span>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-header bg-white border-bottom p-4">
                        <h5 class="fw-bold mb-0">Edit Profile</h5>
                    </div>
                    <div class="card-body p-4">
                        <?php if(isset($_GET['success'])): ?>
                            <div class="alert alert-success border-success-subtle bg-success-subtle text-success fade show">
                                <i class="fas fa-check-circle me-2"></i> Profile updated successfully!
                            </div>
                        <?php endif; ?>

                        <form action="api/profile_action.php" method="POST">
                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold text-uppercase text-muted">Full Name</label>
                                    <input type="text" name="fullname" class="form-control form-control-lg fs-6" value="<?php echo htmlspecialchars($user['fullname']); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold text-uppercase text-muted">Email Address</label>
                                    <input type="email" name="email" class="form-control form-control-lg fs-6" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold text-uppercase text-muted">Phone Number</label>
                                    <input type="text" name="phone" class="form-control form-control-lg fs-6" value="<?php echo htmlspecialchars($user['phone']); ?>">
                                </div>
                                <div class="col-12">
                                    <hr class="my-4 text-muted opacity-25">
                                    <h6 class="fw-bold mb-3">Change Password <small class="text-muted fw-normal">(Leave blank to keep current)</small></h6>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold text-uppercase text-muted">New Password</label>
                                    <input type="password" name="password" class="form-control form-control-lg fs-6">
                                </div>
                                <div class="col-12 mt-4 text-end">
                                    <button type="submit" class="btn btn-primary-custom px-4">Save Changes</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
