<?php
include '../config/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';

// Access Control: Only Super Admin (admin role with NO branch_id)
if ($_SESSION['role'] !== 'admin' || !empty($_SESSION['branch_id'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit;
}

// Fetch all stores
$stmt = $pdo->query("SELECT * FROM branches ORDER BY id DESC");
$stores = $stmt->fetchAll();
?>

<div class="main-content">
    <?php include 'includes/topbar.php'; ?>

    <div class="container-fluid p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold mb-0">Store Management</h2>
                <p class="text-muted mb-0">Manage all pharmacy locations and branches across the city.</p>
            </div>
            <button class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#storeModal">
                <i class="fas fa-plus-circle me-2"></i> Add New Store
            </button>
        </div>

        <?php if(isset($_GET['msg'])): ?>
            <div class="alert alert-success border-success-subtle bg-success-subtle text-success fade show mb-4">
                <i class="fas fa-check-circle me-2"></i> <?php echo htmlspecialchars($_GET['msg']); ?>
            </div>
        <?php endif; ?>

        <div class="row g-4">
            <?php foreach($stores as $store): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 hover-lift position-relative overflow-hidden">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div class="bg-primary-subtle text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                <i class="fas fa-store fa-lg"></i>
                            </div>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-light border-0" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v text-muted"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                    <li><a class="dropdown-item" href="#" onclick='editStore(<?php echo json_encode($store); ?>)'><i class="fas fa-edit me-2 text-primary"></i> Edit</a></li>
                                    <li><a class="dropdown-item text-danger" href="api/store_action.php?action=delete&id=<?php echo $store['id']; ?>" onclick="return confirm('Are you sure?')"><i class="fas fa-trash me-2"></i> Delete</a></li>
                                </ul>
                            </div>
                        </div>
                        
                        <h4 class="fw-bold mb-1"><?php echo htmlspecialchars($store['name']); ?></h4>
                        <div class="mb-3">
                            <?php if($store['is_active']): ?>
                                <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3">Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger-subtle text-danger border border-danger-subtle rounded-pill px-3">Inactive</span>
                            <?php endif; ?>
                        </div>

                        <div class="d-flex align-items-start gap-3 mb-2 small text-muted">
                            <i class="fas fa-map-marker-alt mt-1"></i>
                            <span><?php echo nl2br(htmlspecialchars($store['address'] ?? 'No Address')); ?></span>
                        </div>
                        <div class="d-flex align-items-center gap-3 mb-2 small text-muted">
                            <i class="fas fa-phone-alt"></i>
                            <span><?php echo htmlspecialchars($store['phone'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="d-flex align-items-center gap-3 small text-muted">
                            <i class="fas fa-envelope"></i>
                            <span><?php echo htmlspecialchars($store['email'] ?? 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="card-footer bg-light border-0 p-3">
                        <div class="d-flex justify-content-between align-items-center small">
                            <span class="text-muted">ID: #<?php echo $store['id']; ?></span>
                            <a href="index.php?branch_view=<?php echo $store['id']; ?>" class="text-primary fw-bold text-decoration-none">View Dashboard <i class="fas fa-arrow-right ms-1"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Store Modal -->
<div class="modal fade" id="storeModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold" id="modalTitle">Add New Store</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="api/store_action.php" method="POST">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="storeId">
                <div class="modal-body pt-4">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-uppercase text-muted">Store Name</label>
                        <input type="text" name="name" id="storeName" class="form-control form-control-lg fs-6" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-uppercase text-muted">Full Address</label>
                        <textarea name="address" id="storeAddress" class="form-control" rows="2" required></textarea>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-uppercase text-muted">Phone</label>
                            <input type="text" name="phone" id="storePhone" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-uppercase text-muted">Email</label>
                            <input type="email" name="email" id="storeEmail" class="form-control">
                        </div>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="storeActive" value="1" checked>
                        <label class="form-check-label fw-medium" for="storeActive">Store is Active</label>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 pb-4 pe-4">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom px-4">Save Store</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editStore(store) {
    document.getElementById('modalTitle').innerText = 'Edit Store';
    document.getElementById('formAction').value = 'update';
    document.getElementById('storeId').value = store.id;
    document.getElementById('storeName').value = store.name;
    document.getElementById('storeAddress').value = store.address || '';
    document.getElementById('storePhone').value = store.phone || '';
    document.getElementById('storeEmail').value = store.email || '';
    document.getElementById('storeActive').checked = store.is_active == 1;
    
    new bootstrap.Modal(document.getElementById('storeModal')).show();
}

// Reset modal on close
document.getElementById('storeModal').addEventListener('hidden.bs.modal', function () {
    document.getElementById('modalTitle').innerText = 'Add New Store';
    document.getElementById('formAction').value = 'create';
    document.getElementById('storeId').value = '';
    this.querySelector('form').reset();
});
</script>

<?php include 'includes/footer.php'; ?>
