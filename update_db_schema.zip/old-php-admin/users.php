<?php
include '../config/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';

// Access Control: Admin or Manager
if (!in_array($_SESSION['role'], ['admin', 'manager'])) {
    echo "<div class='container p-5 text-center'><h3>Access Denied</h3></div>";
    include 'includes/footer.php';
    exit;
}

$branch_id = $_SESSION['branch_id'] ?? null;
// Super Admin View As
if ($_SESSION['role'] === 'admin' && empty($branch_id) && isset($_GET['branch_view'])) {
    $branch_id = $_GET['branch_view'];
}

// Build Query
$branch_cond = "";
if (!empty($branch_id)) {
    $branch_cond = "WHERE u.branch_id = $branch_id";
}

// Fetch Users
$users = $pdo->query("
    SELECT u.*, b.name as branch_name 
    FROM users u 
    LEFT JOIN branches b ON u.branch_id = b.id 
    $branch_cond
    ORDER BY u.created_at DESC
")->fetchAll();

// Fetch Branches for Modal (Only for Super Admin)
$branches = ($_SESSION['role'] === 'admin' && empty($_SESSION['branch_id'])) ? $pdo->query("SELECT * FROM branches")->fetchAll() : [];
?>

<div class="main-content">
    <?php include 'includes/topbar.php'; ?>

    <div class="container-fluid p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-0">User Management</h2>
            <button class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#addUserModal">
                <i class="fas fa-user-plus me-2"></i> Add New User
            </button>
        </div>

        <div class="table-card">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Branch</th>
                            <th>Phone</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($users as $user): ?>
                            <tr>
                                <td class="ps-4 fw-bold">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm bg-light rounded-circle d-flex align-items-center justify-content-center me-2 text-primary fw-bold" style="width: 32px; height: 32px;">
                                            <?php echo strtoupper(substr($user['fullname'], 0, 1)); ?>
                                        </div>
                                        <?php echo htmlspecialchars($user['fullname']); ?>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td>
                                    <?php 
                                    $badge = match($user['role']) {
                                        'admin' => 'danger-subtle text-danger border border-danger-subtle',
                                        'manager' => 'primary-subtle text-primary border border-primary-subtle',
                                        'customer' => 'info-subtle text-info border border-info-subtle',
                                        default => 'secondary'
                                    };
                                    echo "<span class='badge bg-$badge'>" . ucfirst($user['role']) . "</span>";
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($user['branch_name'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($user['phone']); ?></td>
                                <td class="small text-muted"><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary" onclick='editUser(<?php echo json_encode($user); ?>)'>
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <?php if($user['id'] != $_SESSION['user_id']): ?>
                                        <form action="api/user_action.php" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Add New User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="api/user_action.php" method="POST">
                <input type="hidden" name="action" value="create">
                <div class="modal-body pt-4">
                    <div class="mb-3">
                        <label class="form-label text-muted small text-uppercase fw-bold">Full Name</label>
                        <input type="text" class="form-control" name="fullname" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted small text-uppercase fw-bold">Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted small text-uppercase fw-bold">Phone</label>
                            <input type="text" class="form-control" name="phone">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small text-uppercase fw-bold">Password</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small text-uppercase fw-bold">Role</label>
                        <select class="form-select" name="role" required id="roleSelect">
                            <option value="customer">Customer</option>
                            <option value="manager">Branch Manager</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="mb-3" id="branchField" style="display:none;">
                        <label class="form-label text-muted small text-uppercase fw-bold">Assign Branch</label>
                        <select class="form-select" name="branch_id">
                            <option value="">Select Branch</option>
                            <?php foreach($branches as $b): ?>
                                <option value="<?php echo $b['id']; ?>"><?php echo htmlspecialchars($b['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 pb-4 pe-4">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary-custom px-4">Create User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const branchField = document.getElementById('branchField');
    if (this.value === 'manager') {
        branchField.style.display = 'block';
    } else {
        branchField.style.display = 'none';
        document.querySelector('select[name="branch_id"]').value = '';
    }
});

// Edit Mode Logic
document.getElementById('edit_roleSelect').addEventListener('change', function() {
    const branchField = document.getElementById('edit_branchField');
    if (this.value === 'manager') {
        branchField.style.display = 'block';
    } else {
        branchField.style.display = 'none';
        document.getElementById('edit_branch_select').value = '';
    }
});

function editUser(user) {
    document.getElementById('edit_user_id').value = user.id;
    document.getElementById('edit_fullname').value = user.fullname;
    document.getElementById('edit_email').value = user.email;
    document.getElementById('edit_phone').value = user.phone || '';
    
    // Set Role
    const roleSelect = document.getElementById('edit_roleSelect');
    roleSelect.value = user.role;
    
    // Trigger change event to show/hide branch field
    roleSelect.dispatchEvent(new Event('change'));
    
    // Set Branch
    if (user.branch_id) {
        document.getElementById('edit_branch_select').value = user.branch_id;
    }
    
    new bootstrap.Modal(document.getElementById('editUserModal')).show();
}
</script>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Edit User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="api/user_action.php" method="POST">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="user_id" id="edit_user_id">
                <div class="modal-body pt-4">
                    <div class="mb-3">
                        <label class="form-label text-muted small text-uppercase fw-bold">Full Name</label>
                        <input type="text" class="form-control" name="fullname" id="edit_fullname" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted small text-uppercase fw-bold">Email</label>
                            <input type="email" class="form-control" name="email" id="edit_email" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted small text-uppercase fw-bold">Phone</label>
                            <input type="text" class="form-control" name="phone" id="edit_phone">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small text-uppercase fw-bold">Password (Leave blank to keep current)</label>
                        <input type="password" class="form-control" name="password" placeholder="New Password">
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small text-uppercase fw-bold">Role</label>
                        <select class="form-select" name="role" required id="edit_roleSelect">
                            <option value="customer">Customer</option>
                            <option value="manager">Branch Manager</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="mb-3" id="edit_branchField" style="display:none;">
                        <label class="form-label text-muted small text-uppercase fw-bold">Assign Branch</label>
                        <select class="form-select" name="branch_id" id="edit_branch_select">
                            <option value="">Select Branch</option>
                            <?php foreach($branches as $b): ?>
                                <option value="<?php echo $b['id']; ?>"><?php echo htmlspecialchars($b['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 pb-4 pe-4">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary-custom px-4">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
