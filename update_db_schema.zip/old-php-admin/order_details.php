<?php
include '../config/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit;
}

$order_id = $_GET['id'];
$role = $_SESSION['role'];
$branch_id = $_SESSION['branch_id'] ?? null;

// Fetch Order Details with User and Branch Info
$stmt = $pdo->prepare("
    SELECT o.*, u.fullname, u.email, u.phone, b.name as branch_name 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    LEFT JOIN branches b ON o.branch_id = b.id 
    WHERE o.id = ?
");
$stmt->execute([$order_id]);
$order = $stmt->fetch();

// Security Check
if (!$order) {
    echo "<div class='main-content'><div class='container p-5 text-center'><h3>Order Not Found</h3><a href='orders.php' class='btn btn-primary'>Back</a></div></div>";
    include 'includes/footer.php';
    exit;
}

if ($role === 'manager' && $order['branch_id'] != $branch_id) {
    echo "<div class='main-content'><div class='container p-5 text-center'><h3>Access Denied</h3><a href='orders.php' class='btn btn-primary'>Back</a></div></div>";
    include 'includes/footer.php';
    exit;
}

// Fetch Order Items
$stmtItems = $pdo->prepare("
    SELECT oi.*, p.name as product_name, p.image, p.sku 
    FROM order_items oi 
    JOIN products p ON oi.product_id = p.id 
    WHERE oi.order_id = ?
");
$stmtItems->execute([$order_id]);
$items = $stmtItems->fetchAll();
?>

<div class="main-content">
    <?php include 'includes/topbar.php'; ?>

    <div class="container-fluid p-4">
        <!-- Breadcrumb & Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="orders.php" class="text-decoration-none text-muted">Orders</a></li>
                    <li class="breadcrumb-item active fw-bold" aria-current="page">#<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></li>
                </ol>
            </nav>
            <div class="d-flex gap-2">
                <a href="orders.php" class="btn btn-light border"><i class="fas fa-arrow-left me-2"></i> Back</a>
                <button class="btn btn-primary-custom" onclick="window.print()"><i class="fas fa-print me-2"></i> Print Invoice</button>
            </div>
        </div>

        <div class="row g-4">
            <!-- Left Column: Items & Summary -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-header bg-white border-bottom py-3 px-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0">Order Items</h5>
                             <?php 
                            $statusClass = match($order['status']) {
                                'completed' => 'success',
                                'processing' => 'info',
                                'cancelled' => 'danger',
                                default => 'warning'
                            };
                            ?>
                            <span class="badge bg-<?php echo $statusClass; ?>-subtle text-<?php echo $statusClass; ?> border border-<?php echo $statusClass; ?>-subtle px-3 py-2 rounded-pill">
                                <?php echo ucfirst($order['status']); ?>
                            </span>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table align-middle mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th class="ps-4">Product</th>
                                        <th class="text-center">Price</th>
                                        <th class="text-center">Quantity</th>
                                        <th class="text-end pe-4">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($items as $item): ?>
                                        <tr>
                                            <td class="ps-4">
                                                <div class="d-flex align-items-center gap-3">
                                                    <?php 
                                                        $imgSrc = !empty($item['image']) ? (strpos($item['image'], 'http') === 0 ? $item['image'] : '../assets/images/products/'.$item['image']) : '';
                                                        if(empty($imgSrc)) {
                                                            $imgSrc = 'https://ui-avatars.com/api/?name='.urlencode($item['product_name']).'&background=random&color=fff&size=60';
                                                        }
                                                    ?>
                                                    <img src="<?php echo $imgSrc; ?>" class="rounded border" width="60" height="60" style="object-fit: cover;">
                                                    <div>
                                                        <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($item['product_name']); ?></h6>
                                                        <small class="text-muted">SKU: <?php echo htmlspecialchars($item['sku']); ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="text-center">₹<?php echo number_format($item['price'], 2); ?></td>
                                            <td class="text-center"><?php echo $item['quantity']; ?></td>
                                            <td class="text-end pe-4 fw-bold">₹<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer bg-white p-4">
                        <div class="row justify-content-end">
                            <div class="col-md-5">
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted">Subtotal</span>
                                    <span class="fw-bold">₹<?php echo number_format($order['total_amount'], 2); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted">Shipping</span>
                                    <span class="text-success fw-bold">Free</span>
                                </div>
                                <div class="d-flex justify-content-between border-top pt-3 mt-2">
                                    <h5 class="fw-bold">Total</h5>
                                    <h5 class="fw-bold text-primary-custom">₹<?php echo number_format($order['total_amount'], 2); ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Customer & Info -->
            <div class="col-lg-4">
                <!-- Customer Details -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-header bg-white border-bottom py-3 px-4">
                        <h5 class="fw-bold mb-0">Customer Details</h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center mb-4">
                            <div class="avatar-md bg-light rounded-circle d-flex align-items-center justify-content-center me-3 text-primary fw-bold fs-4" style="width: 50px; height: 50px;">
                                <?php echo strtoupper(substr($order['fullname'], 0, 1)); ?>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($order['fullname']); ?></h6>
                                <small class="text-muted">Customer ID: #<?php echo $order['user_id']; ?></small>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <small class="text-muted text-uppercase fw-bold d-block mb-1" style="font-size: 0.7rem;">Email Address</small>
                            <div class="d-flex align-items-center gap-2">
                                <i class="fas fa-envelope text-muted"></i>
                                <span><?php echo htmlspecialchars($order['email']); ?></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <small class="text-muted text-uppercase fw-bold d-block mb-1" style="font-size: 0.7rem;">Phone Number</small>
                            <div class="d-flex align-items-center gap-2">
                                <i class="fas fa-phone text-muted"></i>
                                <span><?php echo htmlspecialchars($order['phone'] ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <small class="text-muted text-uppercase fw-bold d-block mb-1" style="font-size: 0.7rem;">Shipping Address</small>
                            <div class="d-flex align-items-start gap-2">
                                <i class="fas fa-map-marker-alt text-muted mt-1"></i>
                                <span><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Update Status -->
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-header bg-white border-bottom py-3 px-4">
                        <h5 class="fw-bold mb-0">Update Status</h5>
                    </div>
                    <div class="card-body p-4">
                        <form action="api/order_action.php" method="POST">
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            
                            <div class="mb-3">
                                <label class="form-label text-muted small fw-bold">Order Status</label>
                                <select class="form-select" name="status">
                                    <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="processing" <?php echo $order['status'] == 'processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="completed" <?php echo $order['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary-custom w-100">Update Status</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
