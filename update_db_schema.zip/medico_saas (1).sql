-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2026 at 03:08 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medico_saas`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `name`, `address`, `city`, `phone`, `latitude`, `longitude`, `is_active`, `created_at`, `email`) VALUES
(1, 'Shreyash Medical Central', '123 Main St, Laxmipuri, Kolhapur', '', '9876543210', 16.70500000, 74.24330000, 1, '2026-02-18 01:20:32', 'central@medico.com'),
(2, 'Shreyash Medical Rajarampuri', '45 2nd Lane, Rajarampuri, Kolhapur', '', '9876543211', 16.69900000, 74.25000000, 1, '2026-02-18 01:20:32', 'rajarampuri@medico.com'),
(3, 'Shreyash Medical Shahupuri', 'Station Road, Shahupuri, Kolhapur', '', '9876543212', 16.70800000, 74.24000000, 1, '2026-02-18 01:20:32', 'shahupuri@medico.com'),
(4, 'Shreyash Medical Tarabai Park', 'Near Sasane Ground, Tarabai Park, Kolhapur', '', '9876543213', 16.71200000, 74.23500000, 1, '2026-02-18 01:20:32', 'tarabaipark@medico.com'),
(5, 'Shreyash Medical Ruikar Colony', 'Uni Road, Ruikar Colony, Kolhapur', '', '9876543214', 16.70200000, 74.26000000, 1, '2026-02-18 01:20:32', 'ruikar@medico.com');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `branch_id`, `product_id`, `quantity`, `updated_at`) VALUES
(1, 1, 4, 18, '2026-02-18 01:20:32'),
(2, 1, 5, 63, '2026-02-18 01:20:32'),
(3, 1, 8, 90, '2026-02-18 01:20:32'),
(4, 1, 2, 74, '2026-02-18 01:20:32'),
(5, 1, 3, 23, '2026-02-18 01:20:32'),
(6, 1, 7, 56, '2026-02-18 01:20:32'),
(7, 1, 1, 98, '2026-02-18 01:20:32'),
(8, 1, 6, 67, '2026-02-18 01:20:32'),
(9, 2, 4, 87, '2026-02-18 01:20:32'),
(10, 2, 5, 72, '2026-02-18 01:20:32'),
(11, 2, 8, 42, '2026-02-18 01:20:32'),
(12, 2, 2, 35, '2026-02-18 01:20:32'),
(13, 2, 3, 73, '2026-02-18 01:20:32'),
(14, 2, 7, 22, '2026-02-18 01:20:32'),
(15, 2, 1, 5, '2026-02-18 01:20:32'),
(16, 2, 6, 23, '2026-02-18 01:20:32'),
(17, 3, 4, 55, '2026-02-18 01:20:32'),
(18, 3, 5, 85, '2026-02-18 01:20:32'),
(19, 3, 8, 83, '2026-02-18 01:20:32'),
(20, 3, 2, 61, '2026-02-18 01:20:32'),
(21, 3, 3, 7, '2026-02-18 01:20:32'),
(22, 3, 7, 75, '2026-02-18 01:20:32'),
(23, 3, 1, 36, '2026-02-18 01:20:32'),
(24, 3, 6, 46, '2026-02-18 01:20:32'),
(25, 4, 4, 47, '2026-02-18 01:20:32'),
(26, 4, 5, 19, '2026-02-18 01:20:32'),
(27, 4, 8, 93, '2026-02-18 01:20:32'),
(28, 4, 2, 4, '2026-02-18 01:20:32'),
(29, 4, 3, 61, '2026-02-18 01:20:32'),
(30, 4, 7, 16, '2026-02-18 01:20:32'),
(31, 4, 1, 33, '2026-02-18 01:20:32'),
(32, 4, 6, 19, '2026-02-18 01:20:32'),
(33, 5, 4, 23, '2026-02-18 01:20:32'),
(34, 5, 5, 69, '2026-02-18 01:20:32'),
(35, 5, 8, 47, '2026-02-18 01:20:32'),
(36, 5, 2, 93, '2026-02-18 01:20:32'),
(37, 5, 3, 66, '2026-02-18 01:20:32'),
(38, 5, 7, 75, '2026-02-18 01:20:32'),
(39, 5, 1, 29, '2026-02-18 01:20:32'),
(40, 5, 6, 26, '2026-02-18 01:20:32');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(50) DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','completed','cancelled') NOT NULL DEFAULT 'pending',
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `shipping_address` text NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT 'COD'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_amount`, `status`, `order_date`, `shipping_address`, `branch_id`, `payment_method`) VALUES
(1, 11, 9899.00, 'pending', '2026-02-07 20:50:32', 'Kolhapur', 1, 'cod'),
(2, 14, 3195.00, 'processing', '2026-01-22 20:50:32', 'Kolhapur', 1, 'cod'),
(3, 14, 738.00, 'completed', '2026-02-08 20:50:32', 'Kolhapur', 1, 'cod'),
(4, 8, 2817.00, 'cancelled', '2026-01-31 20:50:32', 'Kolhapur', 1, 'cod'),
(5, 13, 789.00, 'completed', '2026-02-02 20:50:32', 'Kolhapur', 1, 'cod'),
(6, 15, 729.00, 'pending', '2026-02-15 20:50:32', 'Kolhapur', 1, 'cod'),
(7, 7, 12198.00, 'pending', '2026-02-08 20:50:32', 'Kolhapur', 1, 'cod'),
(8, 11, 1750.00, 'completed', '2026-02-12 20:50:32', 'Kolhapur', 2, 'cod'),
(9, 12, 3447.00, 'cancelled', '2026-01-29 20:50:32', 'Kolhapur', 2, 'cod'),
(10, 7, 589.00, 'pending', '2026-02-11 20:50:32', 'Kolhapur', 2, 'cod'),
(11, 11, 1547.00, 'cancelled', '2026-01-21 20:50:32', 'Kolhapur', 2, 'cod'),
(12, 12, 8598.00, 'cancelled', '2026-01-25 20:50:32', 'Kolhapur', 2, 'cod'),
(13, 8, 5788.00, 'cancelled', '2026-01-22 20:50:32', 'Kolhapur', 2, 'cod'),
(14, 12, 1297.00, 'pending', '2026-01-22 20:50:32', 'Kolhapur', 2, 'cod'),
(15, 15, 5444.00, 'completed', '2026-01-21 20:50:32', 'Kolhapur', 2, 'cod'),
(16, 12, 480.00, 'pending', '2026-01-30 20:50:32', 'Kolhapur', 2, 'cod'),
(17, 12, 720.00, 'pending', '2026-02-01 20:50:32', 'Kolhapur', 2, 'cod'),
(18, 9, 6297.00, 'cancelled', '2026-01-21 20:50:32', 'Kolhapur', 3, 'cod'),
(19, 14, 1039.00, 'cancelled', '2026-01-23 20:50:32', 'Kolhapur', 3, 'cod'),
(20, 9, 560.00, 'cancelled', '2026-02-15 20:50:32', 'Kolhapur', 3, 'cod'),
(21, 13, 60.00, 'cancelled', '2026-01-27 20:50:32', 'Kolhapur', 3, 'cod'),
(22, 11, 2310.00, 'completed', '2026-02-17 20:50:32', 'Kolhapur', 3, 'cod'),
(23, 16, 2078.00, 'completed', '2026-02-16 20:50:32', 'Kolhapur', 4, 'cod'),
(24, 12, 13017.00, 'processing', '2026-01-21 20:50:32', 'Kolhapur', 4, 'cod'),
(25, 16, 3600.00, 'cancelled', '2026-01-19 20:50:32', 'Kolhapur', 4, 'cod'),
(26, 10, 1299.00, 'completed', '2026-02-07 20:50:32', 'Kolhapur', 4, 'cod'),
(27, 13, 2097.00, 'completed', '2026-02-11 20:50:32', 'Kolhapur', 4, 'cod'),
(28, 12, 60.00, 'cancelled', '2026-02-03 20:50:32', 'Kolhapur', 4, 'cod'),
(29, 7, 2834.00, 'pending', '2026-01-26 20:50:32', 'Kolhapur', 5, 'cod'),
(30, 16, 6810.00, 'processing', '2026-02-01 20:50:32', 'Kolhapur', 5, 'cod'),
(31, 12, 947.00, 'pending', '2026-02-02 20:50:32', 'Kolhapur', 5, 'cod'),
(32, 8, 5238.00, 'pending', '2026-01-27 20:50:32', 'Kolhapur', 5, 'cod'),
(33, 11, 3747.00, 'pending', '2026-02-12 20:50:32', 'Kolhapur', 5, 'cod'),
(34, 8, 1050.00, 'processing', '2026-01-26 20:50:32', 'Kolhapur', 5, 'cod');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 1, 8, 3, 1800.00),
(2, 1, 8, 2, 1800.00),
(3, 1, 4, 1, 899.00),
(4, 2, 4, 1, 899.00),
(5, 2, 3, 1, 699.00),
(6, 2, 7, 1, 199.00),
(7, 2, 3, 2, 699.00),
(8, 3, 1, 1, 30.00),
(9, 3, 5, 1, 250.00),
(10, 3, 7, 2, 199.00),
(11, 3, 1, 2, 30.00),
(12, 4, 4, 3, 899.00),
(13, 4, 6, 1, 120.00),
(14, 5, 1, 3, 30.00),
(15, 5, 3, 1, 699.00),
(16, 6, 1, 1, 30.00),
(17, 6, 3, 1, 699.00),
(18, 7, 8, 3, 1800.00),
(19, 7, 3, 2, 699.00),
(20, 7, 8, 3, 1800.00),
(21, 8, 2, 3, 350.00),
(22, 8, 2, 2, 350.00),
(23, 9, 2, 1, 350.00),
(24, 9, 5, 1, 250.00),
(25, 9, 5, 3, 250.00),
(26, 9, 3, 3, 699.00),
(27, 10, 1, 1, 30.00),
(28, 10, 6, 3, 120.00),
(29, 10, 7, 1, 199.00),
(30, 11, 4, 1, 899.00),
(31, 11, 7, 2, 199.00),
(32, 11, 5, 1, 250.00),
(33, 12, 3, 2, 699.00),
(34, 12, 8, 1, 1800.00),
(35, 12, 8, 3, 1800.00),
(36, 13, 8, 2, 1800.00),
(37, 13, 1, 1, 30.00),
(38, 13, 6, 3, 120.00),
(39, 13, 4, 2, 899.00),
(40, 14, 4, 1, 899.00),
(41, 14, 7, 2, 199.00),
(42, 15, 4, 3, 899.00),
(43, 15, 8, 1, 1800.00),
(44, 15, 2, 1, 350.00),
(45, 15, 7, 3, 199.00),
(46, 16, 6, 3, 120.00),
(47, 16, 6, 1, 120.00),
(48, 17, 5, 1, 250.00),
(49, 17, 2, 1, 350.00),
(50, 17, 6, 1, 120.00),
(51, 18, 8, 2, 1800.00),
(52, 18, 4, 3, 899.00),
(53, 19, 5, 3, 250.00),
(54, 19, 7, 1, 199.00),
(55, 19, 1, 3, 30.00),
(56, 20, 1, 2, 30.00),
(57, 20, 5, 2, 250.00),
(58, 21, 1, 2, 30.00),
(59, 22, 6, 1, 120.00),
(60, 22, 1, 3, 30.00),
(61, 22, 2, 3, 350.00),
(62, 22, 2, 3, 350.00),
(63, 23, 5, 1, 250.00),
(64, 23, 4, 2, 899.00),
(65, 23, 1, 1, 30.00),
(66, 24, 8, 3, 1800.00),
(67, 24, 8, 3, 1800.00),
(68, 24, 6, 1, 120.00),
(69, 24, 3, 3, 699.00),
(70, 25, 8, 2, 1800.00),
(71, 26, 6, 3, 120.00),
(72, 26, 6, 2, 120.00),
(73, 26, 5, 2, 250.00),
(74, 26, 7, 1, 199.00),
(75, 27, 3, 3, 699.00),
(76, 28, 1, 2, 30.00),
(77, 29, 7, 1, 199.00),
(78, 29, 4, 2, 899.00),
(79, 29, 6, 2, 120.00),
(80, 29, 7, 3, 199.00),
(81, 30, 8, 2, 1800.00),
(82, 30, 6, 3, 120.00),
(83, 30, 8, 1, 1800.00),
(84, 30, 2, 3, 350.00),
(85, 31, 7, 3, 199.00),
(86, 31, 2, 1, 350.00),
(87, 32, 6, 2, 120.00),
(88, 32, 3, 2, 699.00),
(89, 32, 8, 2, 1800.00),
(90, 33, 4, 3, 899.00),
(91, 33, 2, 3, 350.00),
(92, 34, 2, 3, 350.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `pack_size` varchar(50) DEFAULT '1 Unit',
  `discount` int(11) DEFAULT 0,
  `category` varchar(100) DEFAULT 'Medicines'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `slug`, `description`, `price`, `sku`, `category_id`, `image`, `is_active`, `created_at`, `pack_size`, `discount`, `category`) VALUES
(1, 'Paracetamol 650mg Tablet', 'paracetamol-650', 'Effective for fever and mild to moderate pain relief. Contains Paracetamol IP 650mg.', 30.00, 'MED001', NULL, 'https://placehold.co/400x400/e9f5eb/2a6b42?text=Paracetamol', 1, '2026-02-16 15:31:16', '10 Tablets', 0, 'Medicines'),
(2, 'Vitamin C + Zinc Capsules', 'vit-c-zinc', 'Boosts immunity and promotes skin health. Daily supplement for adults.', 350.00, 'HEA001', NULL, 'https://placehold.co/400x400/e9f5eb/2a6b42?text=Vitamin+C', 1, '2026-02-16 15:31:16', '60 Capsules', 10, 'Healthcare'),
(3, 'Diabetes Care Protein Powder', 'diabetes-protein', 'Low GI protein powder for diabetic care. Chocolate flavor.', 699.00, 'HEA002', NULL, 'https://placehold.co/400x400/e9f5eb/2a6b42?text=Protein+Powder', 1, '2026-02-16 15:31:16', '400g Jar', 5, 'Healthcare'),
(4, 'Baby Diapers (Medium) - 50 Count', 'baby-diapers-m', '', 899.00, 'BAB001', NULL, 'https://via.placeholder.com/150', 1, '2026-02-16 15:31:16', 'Pack of 50', 15, 'Baby Care'),
(5, 'Digital Thermometer', 'digi-thermometer', 'Fast and accurate reading. Waterproof and unbreakable.', 250.00, 'DEV001', NULL, 'https://placehold.co/400x400/e9f5eb/2a6b42?text=Thermometer', 1, '2026-02-16 15:31:16', '1 Unit', 0, 'Health Devices'),
(6, 'Cough Syrup (Ayurvedic)', 'cough-syrup-ayur', 'Herbal relief for dry and wet cough. Non-drowsy formula.', 120.00, 'MED002', NULL, 'https://placehold.co/400x400/e9f5eb/2a6b42?text=Cough+Syrup', 1, '2026-02-16 15:31:16', '100ml Bottle', 0, 'Medicines'),
(7, 'N95 Face Mask (Pack of 5)', 'n95-mask-5', '5-layer protection against virus and pollution. Reusable and washable.', 199.00, 'HEA003', NULL, 'https://placehold.co/400x400/e9f5eb/2a6b42?text=N95+Mask', 1, '2026-02-16 15:31:16', 'Pack of 5', 20, 'Healthcare'),
(8, 'bp Monitor (Digital)', 'bp-monitor', 'Automatic Blood Pressure Monitor with large display and memory function.', 1800.00, 'DEV002', NULL, 'https://placehold.co/400x400/e9f5eb/2a6b42?text=BP+Monitor', 1, '2026-02-16 15:31:16', '1 Unit', 25, 'Devices');

-- --------------------------------------------------------

--
-- Table structure for table `stock_requests`
--

CREATE TABLE `stock_requests` (
  `id` int(11) NOT NULL,
  `requester_branch_id` int(11) NOT NULL,
  `provider_branch_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` enum('pending','approved','rejected','completed') NOT NULL DEFAULT 'pending',
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `processed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','manager','customer') NOT NULL DEFAULT 'customer',
  `branch_id` int(11) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `role`, `branch_id`, `phone`, `created_at`) VALUES
(1, 'Super Admin', 'super@medico.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'admin', NULL, NULL, '2026-02-18 01:20:32'),
(2, 'Manager Medico Central', 'store1@medico.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'manager', 1, '9988776655', '2026-02-18 01:20:32'),
(3, 'Manager Medico Rajarampuri', 'store2@medico.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'manager', 2, '9988776655', '2026-02-18 01:20:32'),
(4, 'Manager Medico Shahupuri', 'store3@medico.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'manager', 3, '9988776655', '2026-02-18 01:20:32'),
(5, 'Manager Medico Tarabai Park', 'store4@medico.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'manager', 4, '9988776655', '2026-02-18 01:20:32'),
(6, 'Manager Medico Ruikar Colony', 'store5@medico.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'manager', 5, '9988776655', '2026-02-18 01:20:32'),
(7, 'Customer 1', 'customer1@gmail.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'customer', NULL, '9870000001', '2026-02-18 01:20:32'),
(8, 'Customer 2', 'customer2@gmail.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'customer', NULL, '9870000002', '2026-02-18 01:20:32'),
(9, 'Customer 3', 'customer3@gmail.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'customer', NULL, '9870000003', '2026-02-18 01:20:32'),
(10, 'Customer 4', 'customer4@gmail.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'customer', NULL, '9870000004', '2026-02-18 01:20:32'),
(11, 'Customer 5', 'customer5@gmail.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'customer', NULL, '9870000005', '2026-02-18 01:20:32'),
(12, 'Customer 6', 'customer6@gmail.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'customer', NULL, '9870000006', '2026-02-18 01:20:32'),
(13, 'Customer 7', 'customer7@gmail.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'customer', NULL, '9870000007', '2026-02-18 01:20:32'),
(14, 'Customer 8', 'customer8@gmail.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'customer', NULL, '9870000008', '2026-02-18 01:20:32'),
(15, 'Customer 9', 'customer9@gmail.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'customer', NULL, '9870000009', '2026-02-18 01:20:32'),
(16, 'Customer 10', 'customer10@gmail.com', '$2y$10$7AIMPzwJH6I8nyaqlOhSpOIk7qg5JQMwuCYnXEdWI8MoP8bog.roK', 'customer', NULL, '98700000010', '2026-02-18 01:20:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `branch_product` (`branch_id`,`product_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `stock_requests`
--
ALTER TABLE `stock_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `stock_requests`
--
ALTER TABLE `stock_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
