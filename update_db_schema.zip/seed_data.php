<?php
require 'config/db.php';

// Configuration
$password = password_hash('123456', PASSWORD_DEFAULT);
$faker_names = ['John Doe', 'Jane Smith', 'Alice Johnson', 'Bob Brown', 'Charlie Davis', 'Eve Wilson'];

try {
    // 0. Ensure Schema Compatibility
    echo "Updating Schema if needed...<br>";
    try {
        $pdo->exec("ALTER TABLE orders ADD COLUMN branch_id INT DEFAULT NULL");
    } catch (Exception $e) {} // Column likely exists
    try {
        $pdo->exec("ALTER TABLE orders ADD COLUMN payment_method VARCHAR(50) DEFAULT 'COD'");
    } catch (Exception $e) {}
    try {
        $pdo->exec("ALTER TABLE orders ADD COLUMN shipping_address TEXT");
    } catch (Exception $e) {}
    try {
        $pdo->exec("ALTER TABLE orders ADD COLUMN order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
    } catch (Exception $e) {}

    echo "Cleaning up old data...<br>";
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    $pdo->exec("TRUNCATE TABLE branches"); // ids reset to 1
    $pdo->exec("TRUNCATE TABLE users");
    $pdo->exec("TRUNCATE TABLE inventory");
    $pdo->exec("TRUNCATE TABLE orders");
    $pdo->exec("TRUNCATE TABLE order_items");
    $pdo->exec("TRUNCATE TABLE notifications");
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

    $pdo->beginTransaction();

    echo "Creating Super Admin...<br>";
    $stmt = $pdo->prepare("INSERT INTO users (fullname, email, password, role, branch_id) VALUES (?, ?, ?, ?, NULL)");
    $stmt->execute(['Super Admin', 'super@medico.com', $password, 'admin']);


    echo "Creating 5 Branches...<br>";
    $branches = [
        ['name' => 'Medico Central', 'address' => '123 Main St, Laxmipuri, Kolhapur', 'phone' => '9876543210', 'email' => 'central@medico.com', 'lat' => '16.7050', 'lng' => '74.2433'],
        ['name' => 'Medico Rajarampuri', 'address' => '45 2nd Lane, Rajarampuri, Kolhapur', 'phone' => '9876543211', 'email' => 'rajarampuri@medico.com', 'lat' => '16.6990', 'lng' => '74.2500'],
        ['name' => 'Medico Shahupuri', 'address' => 'Station Road, Shahupuri, Kolhapur', 'phone' => '9876543212', 'email' => 'shahupuri@medico.com', 'lat' => '16.7080', 'lng' => '74.2400'],
        ['name' => 'Medico Tarabai Park', 'address' => 'Near Sasane Ground, Tarabai Park, Kolhapur', 'phone' => '9876543213', 'email' => 'tarabaipark@medico.com', 'lat' => '16.7120', 'lng' => '74.2350'],
        ['name' => 'Medico Ruikar Colony', 'address' => 'Uni Road, Ruikar Colony, Kolhapur', 'phone' => '9876543214', 'email' => 'ruikar@medico.com', 'lat' => '16.7020', 'lng' => '74.2600'],
    ];

    $branch_ids = [];
    foreach ($branches as $b) {
        $stmt = $pdo->prepare("INSERT INTO branches (name, address, phone, email, latitude, longitude, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([$b['name'], $b['address'], $b['phone'], $b['email'], $b['lat'], $b['lng']]);
        $branch_ids[] = $pdo->lastInsertId();
    }


    echo "Creating 5 Store Managers...<br>";
    foreach ($branch_ids as $index => $bid) {
        $email = "store" . ($index + 1) . "@medico.com";
        $name = "Manager " . $branches[$index]['name'];
        $stmt = $pdo->prepare("INSERT INTO users (fullname, email, password, role, branch_id, phone, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$name, $email, $password, 'manager', $bid, '9988776655']);
    }

    
    echo "Ensuring Products Exist...<br>";
    // Check if products exist, if not, add some dummy ones
    $count = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    if ($count < 5) {
        $dummy_products = [
            ['Paracetamol 650mg', 'Strip of 15 tablets', 30.00, 'Medicine', 'PROD001', 5],
            ['Vitamin C 500mg', 'Bottle of 60 tablets', 350.00, 'Healthcare', 'PROD002', 10],
            ['Digital Thermometer', 'High precision', 250.00, 'Devices', 'PROD003', 0],
            ['N95 Face Mask', 'Pack of 5', 199.00, 'Safety', 'PROD004', 0],
            ['Hand Sanitizer', '500ml Bottle', 249.00, 'Safety', 'PROD005', 0],
            ['Baby Diapers', 'Pack of 40', 699.00, 'Baby Care', 'PROD006', 15],
            ['Protein Powder', '1kg Chocolate', 1200.00, 'Fitness', 'PROD007', 10],
            ['Cough Syrup', '100ml Bottle', 85.00, 'Medicine', 'PROD008', 2],
            ['Pain Relief Gel', '50g Tube', 120.00, 'Medicine', 'PROD009', 5],
            ['Glucometer Kit', 'With 50 strips', 899.00, 'Devices', 'PROD010', 20],
        ];
        $stmt = $pdo->prepare("INSERT INTO products (name, description, price, category, sku, discount, image) VALUES (?, ?, ?, ?, ?, ?, 'https://via.placeholder.com/150')");
        foreach ($dummy_products as $p) {
            $stmt->execute([$p[0], $p[1], $p[2], $p[3], $p[4], $p[5]]);
        }
    }
    $product_ids = $pdo->query("SELECT id FROM products")->fetchAll(PDO::FETCH_COLUMN);


    echo "Seeding Inventory for each Branch...<br>";
    foreach ($branch_ids as $bid) {
        foreach ($product_ids as $pid) {
            // Random quantity between 0 and 100
            $qty = rand(0, 100);
            $stmt = $pdo->prepare("INSERT INTO inventory (product_id, branch_id, quantity, updated_at) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$pid, $bid, $qty]);
        }
    }


    echo "Seeding Orders for each Branch...<br>";
    $statuses = ['pending', 'processing', 'completed', 'cancelled'];
    
    // Create 'Customers' locally for better UX (optional logic, but let's just reuse users table or create dummy users if needed)
    // Actually, let's create a few dummy customers first
    $customer_ids = [];
    for($i=1; $i<=10; $i++) {
        $c_email = "customer$i@gmail.com";
        $c_name = "Customer $i";
         $stmt = $pdo->prepare("INSERT INTO users (fullname, email, password, role, phone, created_at) VALUES (?, ?, ?, 'customer', ?, NOW())");
         $stmt->execute([$c_name, $c_email, $password, '987000000'.$i]);
         $customer_ids[] = $pdo->lastInsertId();
    }

    foreach ($branch_ids as $bid) {
        // Create 5-10 orders per branch
        $num_orders = rand(5, 10);
        for ($i = 0; $i < $num_orders; $i++) {
            $user_id = $customer_ids[array_rand($customer_ids)];
            $status = $statuses[array_rand($statuses)];
            $date = date('Y-m-d H:i:s', strtotime('-' . rand(0, 30) . ' days'));
            $total = 0;

            // Create Order
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, branch_id, total_amount, status, order_date, shipping_address, payment_method) VALUES (?, ?, 0, ?, ?, 'Kolhapur', 'cod')");
            $stmt->execute([$user_id, $bid, $status, $date]);
            $order_id = $pdo->lastInsertId();

            // Create Order Items
            $num_items = rand(1, 4);
            for ($j = 0; $j < $num_items; $j++) {
                $pid = $product_ids[array_rand($product_ids)];
                $qty = rand(1, 3);
                
                // Get Price
                $p_stmt = $pdo->prepare("SELECT price FROM products WHERE id = ?");
                $p_stmt->execute([$pid]);
                $price = $p_stmt->fetchColumn();

                $stmt_item = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt_item->execute([$order_id, $pid, $qty, $price]);
                
                $total += ($price * $qty);
            }

            // Update Order Total
            $pdo->prepare("UPDATE orders SET total_amount = ? WHERE id = ?")->execute([$total, $order_id]);
        }
    }

    $pdo->commit();
    echo "<h3 style='color:green;'>Data Seeding Completed Successfully!</h3>";
    
    echo "<h3>Credentials:</h3>";
    echo "<table border='1' cellpadding='10' style='border-collapse:collapse;'>";
    echo "<tr><th>Role</th><th>Store</th><th>Email</th><th>Password</th></tr>";
    
    echo "<tr><td><b>Super Admin</b></td><td>GLOBAL</td><td>super@medico.com</td><td>123456</td></tr>";
    
    foreach ($branch_ids as $index => $bid) {
        $email = "store" . ($index + 1) . "@medico.com";
        echo "<tr><td>Store Manager</td><td>" . $branches[$index]['name'] . "</td><td>$email</td><td>123456</td></tr>";
    }
    echo "</table>";

} catch (Exception $e) {
    echo $e->getMessage();
    $pdo->rollBack();
    echo "<h3 style='color:red;'>Seeding Failed: " . $e->getMessage() . "</h3>";
}
?>
